// Renders a downloadable PNG "verdict card" (1080x1080) for a product.
import { fmtMoney, fmtPct, fmtDays, fmtDayYear } from "../lib/utils.js";

const COL = { REAL: "#1E5BFF", MISLEADING: "#FF7A1A", FAKE: "#E8590C", NO_CLAIM: "#8AA0C4", COLLECTING: "#9DBBFF", NO_DATA: "#9DBBFF" };
const FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

function wrap(g, text, x, y, maxW, lineH, maxLines) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = "";
  for (const w of words) {
    const test = line ? line + " " + w : w;
    if (g.measureText(test).width > maxW && line) {
      lines.push(line);
      line = w;
    } else line = test;
  }
  if (line) lines.push(line);
  if (lines.length > maxLines) {
    lines.length = maxLines;
    lines[maxLines - 1] = lines[maxLines - 1].replace(/\s*\S*$/, "") + "…";
  }
  lines.forEach((l, i) => g.fillText(l, x, y + i * lineH));
  return y + lines.length * lineH;
}

export function makeShareCard(view, now = Date.now()) {
  const { product, variant, audit } = view;
  const W = 1080;
  const H = 1080;
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const g = c.getContext("2d");
  const navy = "#0A2A66";
  const muted = "#5B6B8C";

  g.fillStyle = "#F6F9FF";
  g.fillRect(0, 0, W, H);

  // header
  g.fillStyle = navy;
  g.fillRect(0, 0, W, 150);
  g.textBaseline = "alphabetic";
  g.fillStyle = "#FFFFFF";
  g.font = `800 54px ${FONT}`;
  g.fillText("Audionic Price Check", 60, 82);
  g.fillStyle = "#FFB27A";
  g.font = `700 30px ${FONT}`;
  g.fillText("Is the sale real?", 60, 124);

  // title
  g.fillStyle = navy;
  g.font = `800 56px ${FONT}`;
  let y = wrap(g, product.title, 60, 240, W - 120, 68, 3);

  // verdict pill
  const label = audit.meta.label;
  g.font = `800 40px ${FONT}`;
  const pw = g.measureText(label).width + 80;
  y += 6;
  g.fillStyle = COL[audit.verdict] || "#1E5BFF";
  roundRect(g, 60, y, pw, 76, 38);
  g.fill();
  g.fillStyle = audit.verdict === "COLLECTING" || audit.verdict === "NO_DATA" ? navy : "#FFFFFF";
  g.fillText(label, 100, y + 52);
  y += 76 + 70;

  // prices
  g.fillStyle = navy;
  g.font = `800 104px ${FONT}`;
  g.fillText(fmtMoney(variant.price), 60, y);
  const nowW = g.measureText(fmtMoney(variant.price)).width;
  if (variant.cmp && variant.cmp > variant.price) {
    g.font = `700 54px ${FONT}`;
    g.fillStyle = "#FF7A1A";
    const t = fmtMoney(variant.cmp);
    g.fillText(t, 60 + nowW + 36, y);
    const tw = g.measureText(t).width;
    g.fillRect(60 + nowW + 36, y - 20, tw, 5);
  }
  y += 56;

  // bars
  if (audit.claimedPct > 0) {
    const bar = (name, pct, color) => {
      g.fillStyle = muted;
      g.font = `700 32px ${FONT}`;
      g.fillText(name, 60, y);
      g.fillStyle = "#EAF1FF";
      roundRect(g, 60, y + 18, 700, 38, 19);
      g.fill();
      g.fillStyle = color;
      const w = Math.max(pct > 0 ? 38 : 0, Math.min(700, 700 * pct));
      if (w > 0) {
        roundRect(g, 60, y + 18, w, 38, 19);
        g.fill();
      }
      g.fillStyle = navy;
      g.font = `800 56px ${FONT}`;
      g.textAlign = "right";
      g.fillText(fmtPct(pct), W - 60, y + 56);
      g.textAlign = "left";
      y += 96;
    };
    bar("Claimed discount", audit.claimedPct, "#FF7A1A");
    bar("Real discount (from tracked prices)", audit.realPct, "#1E5BFF");
  } else {
    g.fillStyle = muted;
    g.font = `600 34px ${FONT}`;
    g.fillText("No crossed-out price is shown for this product.", 60, y + 10);
    y += 80;
  }

  // reason
  g.fillStyle = navy;
  g.font = `600 31px ${FONT}`;
  wrap(g, audit.reasons[0] || "", 60, y + 10, W - 120, 42, 3);

  // footer
  g.fillStyle = navy;
  g.fillRect(0, H - 96, W, 96);
  g.fillStyle = "#A9C0EE";
  g.font = `600 27px ${FONT}`;
  g.fillText(`${audit.confidence} · ${fmtDayYear(now)}`, 60, H - 38);
  return c;
}

export function canvasToBlob(canvas) {
  return new Promise((resolve) => canvas.toBlob((b) => resolve(b), "image/png"));
}

export { fmtDays };
