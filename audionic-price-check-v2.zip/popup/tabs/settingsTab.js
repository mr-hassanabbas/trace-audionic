// Settings tab.
import { patchSettings, DEFAULT_SETTINGS } from "../../lib/storage.js";
import { fmtAgo, esc } from "../../lib/utils.js";
import { send, toast, applyTheme, $ } from "../ui.js";

const INTERVALS = [
  [30, "Every 30 minutes"],
  [60, "Every hour"],
  [180, "Every 3 hours"],
  [360, "Every 6 hours (recommended)"],
  [720, "Every 12 hours"],
  [1440, "Once a day"],
];
const RETENTION = [
  [0, "Keep everything"],
  [365, "1 year"],
  [180, "6 months"],
  [90, "3 months"],
];

const ARCHIVE = ["https://web.archive.org/*"];
const GITHUB = ["https://raw.githubusercontent.com/*"];

export async function render(root, ctx) {
  const s = ctx.settings;
  const meta = ctx.state.meta || {};
  const num = (key, label, hint, min, max) => `
    <div class="field"><label class="lbl" for="${key}">${label}</label>
    <input type="number" id="${key}" data-key="${key}" min="${min}" max="${max}" value="${s[key]}" />
    ${hint ? `<div class="hint">${hint}</div>` : ""}</div>`;
  const sw = (key, label, hint) => `
    <label class="switch"><span><b>${label}</b>${hint ? `<div class="hint small muted">${hint}</div>` : ""}</span><input type="checkbox" data-key="${key}" ${s[key] ? "checked" : ""} /></label>`;

  root.innerHTML = `
    <div class="card">
      <h3>Checking prices</h3>
      <div class="field"><label class="lbl" for="intervalMin">How often to check Audionic</label>
        <select id="intervalMin" data-key="intervalMin">${INTERVALS.map(([v, l]) => `<option value="${v}" ${v === s.intervalMin ? "selected" : ""}>${l}</option>`).join("")}${
    INTERVALS.some(([v]) => v === s.intervalMin) ? "" : `<option value="${s.intervalMin}" selected>Every ${s.intervalMin} minutes</option>`
  }</select>
        <div class="hint">Each check downloads the public product list (a few requests, spaced out). Minimum 30 minutes, to stay polite to the store.</div></div>
      <div class="row"><button class="btn small" id="syncNow">Check now</button><span class="small muted" id="syncInfo">${
        meta.lastSync ? `Last check ${fmtAgo(meta.lastSync)}. ${meta.productCount || 0} products, ${meta.syncCount || 0} ${meta.syncCount === 1 ? "check" : "checks"} so far.` : "No check has completed yet."
      }</span></div>
    </div>

    <div class="card">
      <h3>Notifications &amp; page features</h3>
      ${sw("notifications", "Notifications", "Price drops, target prices, back in stock, suspicious claim changes (watchlist items only).")}
      ${num("alertDropPct", "Notify on price drops of at least (%)", "Applies to products on your watchlist.", 1, 90)}
      ${sw("overlay", "Price-check card on product pages", "The small card at the bottom-right of audionic.co product pages.")}
      ${sw("productDots", "Verdict dots on product cards", "A coloured dot on product thumbnails in collections and search results.")}
      ${sw("urgency", "Spot urgency tactics", "Notes countdown timers, “only N left” and similar wording on product pages you visit.")}
    </div>

    <div class="card">
      <h3>Verdict thresholds</h3>
      <div class="two">
        ${num("realMinPct", "Real deal: min real drop (%)", "", 1, 90)}
        ${num("ratioPct", "…and at least this % of the claim", "", 10, 100)}
        ${num("fakeMinClaim", "Fake-looking: min claim (%)", "", 5, 95)}
        ${num("fakeStableDays", "…price unchanged for (days)", "", 1, 90)}
        ${num("minDays", "Verdict needs at least (days)", "", 1, 30)}
        ${num("eventSharePct", "Store-wide event at (% changed)", "", 5, 100)}
      </div>
      <button class="btn ghost small" id="resetTh" style="margin-top:6px">Reset thresholds</button>
    </div>

    <div class="card">
      <h3>Older prices (optional)</h3>
      ${sw("backfill", "Archive backfill", "Lets the Product tab search the Internet Archive for older copies of a page. Results are approximate. Asks for permission to contact web.archive.org.")}
      ${sw("sharedEnabled", "Shared history file", "Merge a history.json made by the collector (see the collector folder) to get weeks or months of history immediately.")}
      <div class="field"><label class="lbl" for="sharedUrl">Shared history URL</label>
        <input type="url" id="sharedUrl" placeholder="https://raw.githubusercontent.com/you/audionic-history/main/history.json" value="${esc(s.sharedUrl)}" />
        <div class="row" style="margin-top:6px"><button class="btn small" id="saveShared">Save &amp; merge now</button><span class="small muted" id="sharedInfo">${
          meta.lastShared ? `Last merged ${fmtAgo(meta.lastShared)} (${meta.lastSharedMerged || 0} variants).` : ""
        }${meta.lastSharedError ? ` <span style="color:var(--orange-d)">${esc(meta.lastSharedError)}</span>` : ""}</span></div>
        <div class="hint">Must start with https://raw.githubusercontent.com/</div></div>
    </div>

    <div class="card">
      <h3>Data &amp; appearance</h3>
      <div class="field"><label class="lbl" for="retentionDays">Keep history for</label>
        <select id="retentionDays" data-key="retentionDays">${RETENTION.map(([v, l]) => `<option value="${v}" ${v === s.retentionDays ? "selected" : ""}>${l}</option>`).join("")}</select></div>
      <div class="field"><label class="lbl" for="theme">Theme</label>
        <select id="theme" data-key="theme">${[["light", "Light"], ["dark", "Dark (navy)"], ["auto", "Match my system"]].map(([v, l]) => `<option value="${v}" ${v === s.theme ? "selected" : ""}>${l}</option>`).join("")}</select></div>
      <button class="btn danger small" id="clearAll">Clear all tracked data</button>
    </div>

    <div class="card">
      <h3>About &amp; privacy</h3>
      <p class="small">Audionic Price Check records the prices Audionic publishes and compares each advertised discount with what was actually charged. Everything is stored in this browser only.</p>
      <p class="small" style="margin-top:6px">No account, no analytics, no tracking. The extension only talks to <b>audionic.co</b> (the store's public product list), plus <b>web.archive.org</b> and <b>raw.githubusercontent.com</b> if you switch those options on.</p>
      <p class="small muted" style="margin-top:6px">Verdicts describe what tracked prices show, over the period tracked. They are not accusations, and the confidence label tells you how many days they are based on. Independent project, not affiliated with Audionic.</p>
    </div>`;

  /* generic auto-save */
  root.onchange = async (e) => {
    const el = e.target.closest("[data-key]");
    if (!el) return;
    const key = el.dataset.key;
    let val;
    if (el.type === "checkbox") val = el.checked;
    else if (el.type === "number") {
      val = parseFloat(el.value);
      const lo = parseFloat(el.min);
      const hi = parseFloat(el.max);
      if (!Number.isFinite(val)) val = DEFAULT_SETTINGS[key];
      val = Math.min(hi, Math.max(lo, val));
      el.value = val;
    } else if (el.tagName === "SELECT" && (key === "intervalMin" || key === "retentionDays")) val = Number(el.value);
    else val = el.value;

    if (key === "backfill" && val) {
      let ok = false;
      try {
        ok = await chrome.permissions.request({ origins: ARCHIVE });
      } catch {
        /* ignore */
      }
      if (!ok) {
        el.checked = false;
        return toast("Permission for web.archive.org was not granted, so backfill stays off.", "error");
      }
    }
    ctx.settings = await patchSettings({ [key]: val });
    if (key === "theme") applyTheme(val);
    toast("Saved.");
  };

  $("#syncNow", root).addEventListener("click", async (e) => {
    e.target.disabled = true;
    try {
      const r = await send("syncNow");
      toast(r.firstSync ? `Loaded ${r.products} products. Tracking starts now.` : `Checked ${r.products} products, ${r.changedVariants} changes.`);
      ctx.go("settings");
    } catch (err) {
      toast(err.message, "error");
      e.target.disabled = false;
    }
  });

  $("#resetTh", root).addEventListener("click", async () => {
    const d = DEFAULT_SETTINGS;
    await patchSettings({ realMinPct: d.realMinPct, ratioPct: d.ratioPct, fakeMinClaim: d.fakeMinClaim, fakeStableDays: d.fakeStableDays, minDays: d.minDays, eventSharePct: d.eventSharePct });
    toast("Thresholds reset.");
    ctx.go("settings");
  });

  $("#saveShared", root).addEventListener("click", async (e) => {
    const url = $("#sharedUrl", root).value.trim();
    if (!/^https:\/\/raw\.githubusercontent\.com\//.test(url)) return toast("The URL must start with https://raw.githubusercontent.com/", "error");
    let ok = false;
    try {
      ok = await chrome.permissions.request({ origins: GITHUB });
    } catch {
      /* ignore */
    }
    if (!ok) return toast("Permission for raw.githubusercontent.com was not granted.", "error");
    e.target.disabled = true;
    try {
      await patchSettings({ sharedUrl: url, sharedEnabled: true });
      const r = await send("mergeShared");
      toast(`Merged shared history for ${r.merged} variants.`);
      ctx.settings = await patchSettings({});
      ctx.go("settings");
    } catch (err) {
      toast(err.message, "error");
      e.target.disabled = false;
    }
  });

  const clear = $("#clearAll", root);
  let armed = false;
  clear.addEventListener("click", async () => {
    if (!armed) {
      armed = true;
      clear.textContent = "Click again to delete everything";
      setTimeout(() => {
        armed = false;
        clear.textContent = "Clear all tracked data";
      }, 4000);
      return;
    }
    await send("clearData");
    toast("All tracked data was deleted. Your settings were kept.");
    ctx.go("settings");
    send("syncNow").catch(() => {});
  });
}
