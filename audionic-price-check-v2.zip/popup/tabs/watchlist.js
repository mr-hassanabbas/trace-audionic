// Watchlist tab: everything you asked to be alerted about.
import { buildProductView } from "../../lib/views.js";
import { fmtMoney, fmtPct, esc } from "../../lib/utils.js";
import { setState } from "../../lib/storage.js";
import { toast, badge, $$ } from "../ui.js";

export async function render(root, ctx) {
  const st = ctx.state;
  const items = Object.values(st.watchlist || {})
    .map((w) => {
      const v = buildProductView(st, w.productId, w.variantId, ctx.now);
      return v ? { w, v } : null;
    })
    .filter(Boolean)
    .sort((a, b) => b.w.addedAt - a.w.addedAt);

  if (!items.length) {
    root.innerHTML = `<div class="empty"><h2>Your watchlist is empty</h2>
      <p>Open a product, then use <b>Add to watchlist</b> to get notified about price drops, your target price, back-in-stock and suspicious discount changes.</p></div>`;
    return;
  }

  root.innerHTML =
    `<div class="card"><h3>${items.length} watched ${items.length === 1 ? "item" : "items"}</h3>` +
    items
      .map(({ w, v }) => {
        const p = v.product;
        const x = v.variant;
        const hit = w.target && x.price <= w.target;
        return `<div class="wi" data-vid="${x.id}" style="padding:10px 0;border-bottom:1px solid var(--border)">
          <div class="row">
            <div class="grow click" data-open="${p.id}" style="cursor:pointer">
              <div class="title ellipsis" style="font-weight:700">${esc(p.title)}${p.variants.length > 1 ? ` <span class="muted">· ${esc(x.title)}</span>` : ""}</div>
              <div class="sub small muted">${fmtMoney(x.price)}${x.cmp && x.cmp > x.price ? ` <s style="color:var(--orange)">${fmtMoney(x.cmp)}</s>` : ""} ${x.avail ? "" : '<span class="tag warn">Sold out</span>'} ${hit ? '<span class="tag" style="background:var(--blue);color:#fff">Target reached</span>' : ""}</div>
            </div>
            ${badge(v.audit)}
          </div>
          <div class="row" style="margin-top:8px">
            <div class="grow"><input type="number" class="tgt" min="0" step="1" placeholder="Target price" value="${w.target || ""}" /></div>
            <button class="btn ghost small rm">Remove</button>
          </div>
          <div class="checks" style="margin:6px 0 0">
            <label><input type="checkbox" class="stk" ${w.stockAlert !== false ? "checked" : ""}/> Back in stock</label>
            <label><input type="checkbox" class="clm" ${w.claimAlert !== false ? "checked" : ""}/> Claim raised w/o price drop</label>
          </div>
          ${w.target ? `<div class="small muted" style="margin-top:4px">${hit ? "Currently at or below your target." : `${fmtMoney(x.price - w.target)} above your target (${fmtPct((x.price - w.target) / x.price)} to go).`}</div>` : ""}
        </div>`;
      })
      .join("") +
    `</div>
    <p class="small muted">Alerts are checked every time the catalogue is refreshed (see Settings for how often). Turn notifications on or off in Settings.</p>`;

  const write = async (fn) => {
    const cur = (await chrome.storage.local.get("watchlist")).watchlist || {};
    await setState({ watchlist: fn({ ...cur }) });
  };

  root.onclick = (e) => {
    const o = e.target.closest("[data-open]");
    if (o) ctx.go("product", { productId: Number(o.dataset.open) });
  };
  $$(".wi", root).forEach((row) => {
    const vid = row.dataset.vid;
    const patch = (obj) => write((cur) => ({ ...cur, [vid]: { ...cur[vid], ...obj } }));
    row.querySelector(".tgt").addEventListener("change", async (e) => {
      const t = parseFloat(e.target.value);
      await patch({ target: Number.isFinite(t) && t > 0 ? t : null });
      toast("Target updated.");
    });
    row.querySelector(".stk").addEventListener("change", (e) => patch({ stockAlert: e.target.checked }));
    row.querySelector(".clm").addEventListener("change", (e) => patch({ claimAlert: e.target.checked }));
    row.querySelector(".rm").addEventListener("click", async () => {
      await write((cur) => {
        delete cur[vid];
        return cur;
      });
      toast("Removed from your watchlist.");
      ctx.go("watchlist");
    });
  });
}
