// Product tab: verdict, discount bars, stats, price-history chart, watch controls, urgency tactics, notes.
import { buildProductView, findByHandle } from "../../lib/views.js";
import { drawChart, RANGES, PALETTES } from "../../lib/chart.js";
import { valueAt } from "../../lib/history.js";
import { fmtMoney, fmtPct, fmtDays, fmtDay, fmtTime, fmtDateTime, fmtAgo, esc, handleFromUrl, debounce } from "../../lib/utils.js";
import { setState } from "../../lib/storage.js";
import { send, toast, badge, activeTabUrl, themeName, openProductPage, downloadBlob, $ } from "../ui.js";
import { makeShareCard, canvasToBlob } from "../share.js";

let rangeKey = "30D";

export async function render(root, ctx, opts = {}) {
  const st = ctx.state;
  let productId = opts.productId ?? null;
  const variantId = opts.variantId ?? null;

  if (!productId) {
    const handle = handleFromUrl(await activeTabUrl());
    const p = findByHandle(st.catalog, handle);
    if (p) productId = p.id;
  }
  if (!productId && st.ui.lastProductId && st.catalog[st.ui.lastProductId]) productId = st.ui.lastProductId;
  if (!productId || !st.catalog[productId]) return renderPicker(root, ctx, "Open a product page on audionic.co, or pick a product below.");

  const v = buildProductView(st, productId, variantId, ctx.now);
  if (!v) return renderPicker(root, ctx, "That product is no longer tracked. Pick another one.");
  if (st.ui.lastProductId !== v.product.id) await setState({ ui: { ...st.ui, lastProductId: v.product.id } });

  const { product: p, variant, audit: a } = v;
  const claimed = a.claimedPct > 0;
  const variants = p.variants;

  root.innerHTML = `
    <div class="card">
      <div class="pcard">
        ${p.image ? `<img class="pimg" src="${esc(p.image)}" alt="" />` : `<div class="pimg"></div>`}
        <div class="grow">
          <h2 title="${esc(p.title)}">${esc(p.title)}</h2>
          ${
            variants.length > 1
              ? `<select id="variantSel">${variants
                  .map((x) => `<option value="${x.id}" ${x.id === variant.id ? "selected" : ""}>${esc(x.title)} · ${fmtMoney(x.price)}${x.avail ? "" : " (sold out)"}</option>`)
                  .join("")}</select>`
              : ""
          }
        </div>
        <button class="link" id="changeBtn">Change</button>
      </div>

      <div class="priceRow">
        <span class="now">${fmtMoney(variant.price)}</span>
        ${variant.cmp && variant.cmp > variant.price ? `<span class="cmp">${fmtMoney(variant.cmp)}</span>` : ""}
        ${claimed ? `<span class="claimTag">-${Math.round(a.claimedPct * 100)}% claimed</span>` : ""}
        ${variant.avail ? "" : `<span class="tag warn">Sold out</span>`}
        ${p.delisted ? `<span class="tag warn">No longer listed</span>` : ""}
      </div>
      <div class="row" style="margin-top:8px">${badge(a)}</div>

      ${
        claimed
          ? `<div class="bars">
              <div class="bar claimed"><span>Claimed</span><div class="track"><i style="width:${Math.min(100, Math.round(a.claimedPct * 100))}%"></i></div><b>${fmtPct(a.claimedPct)}</b></div>
              <div class="bar real"><span>Real</span><div class="track"><i style="width:${Math.min(100, Math.round(a.realPct * 100))}%"></i></div><b>${fmtPct(a.realPct)}</b></div>
            </div>`
          : ""
      }
      <ul class="reasons">${a.reasons.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
      <p class="conf">${esc(a.confidence)}. "Real" compares today's price with the highest price actually charged in the last 90 tracked days.</p>
    </div>

    <div class="card">
      <h3>Price stats</h3>
      <div class="stats">
        <div class="stat"><span>Lowest</span><b>${fmtMoney(a.lowest)}</b></div>
        <div class="stat"><span>Highest</span><b>${fmtMoney(a.highest)}</b></div>
        <div class="stat"><span>Average</span><b>${fmtMoney(a.average)}</b></div>
        <div class="stat"><span>Days at this price</span><b>${fmtDays(a.priceStableDays)}</b></div>
        <div class="stat"><span>Times on sale</span><b>${a.timesOnSale}</b></div>
        <div class="stat"><span>Time shown on sale</span><b>${fmtPct(a.saleDayShare)}</b></div>
      </div>
    </div>

    <div class="card">
      <div class="row between"><h3 style="margin:0">Price history</h3>
        <div class="ranges" id="ranges">${RANGES.map((r) => `<button data-r="${r.key}" class="${r.key === rangeKey ? "active" : ""}">${r.key}</button>`).join("")}</div>
      </div>
      <div class="chartWrap"><canvas class="chart" id="chart"></canvas><div class="tip" id="tip"></div></div>
      <div class="legend"><span><i></i>Selling price</span><span><i class="o"></i>Crossed-out price</span><span><i class="h"></i>Approximate (archive/shared)</span></div>
    </div>

    <div class="card">
      <div class="actions">
        <button class="btn ghost small" id="backfillBtn" title="Look for older prices in the Internet Archive">Backfill from Internet Archive</button>
        <button class="btn ghost small" id="shareBtn">Share card (PNG)</button>
        <button class="btn ghost small" id="openBtn">Open on audionic.co</button>
      </div>
    </div>

    <div class="card" id="watchBox"></div>
    ${urgencyHtml(v)}
    <div class="card">
      <h3>My notes</h3>
      <textarea id="notes" placeholder="Anything worth remembering about this product…">${esc(v.note)}</textarea>
    </div>`;

  /* ---- header controls ---- */
  $("#changeBtn", root).onclick = () => renderPicker(root, ctx, "Pick a product to check.");
  const sel = $("#variantSel", root);
  if (sel) sel.onchange = () => ctx.go("product", { productId: p.id, variantId: Number(sel.value) });

  /* ---- chart ---- */
  const canvas = $("#chart", root);
  const tip = $("#tip", root);
  let layout;
  const redraw = (hoverT = null) => {
    const days = RANGES.find((r) => r.key === rangeKey).days;
    layout = drawChart(canvas, { series: v.series, now: ctx.now, days, events: v.events, palette: PALETTES[themeName()], hoverT });
  };
  redraw();
  $("#ranges", root).onclick = (e) => {
    const b = e.target.closest("button[data-r]");
    if (!b) return;
    rangeKey = b.dataset.r;
    root.querySelectorAll("#ranges button").forEach((x) => x.classList.toggle("active", x === b));
    tip.classList.remove("show");
    redraw();
  };
  canvas.addEventListener("mousemove", (ev) => {
    if (!layout || !v.series.length) return;
    const rect = canvas.getBoundingClientRect();
    const x = ev.clientX - rect.left;
    if (x < layout.plot.l || x > layout.plot.r) return;
    const t = Math.min(layout.xToT(x), ctx.now);
    redraw(t);
    const e = valueAt(v.series, t);
    const first = v.series[0].t;
    if (!e) {
      tip.innerHTML = `${fmtDay(t)}<br><span style="opacity:.8">No data before ${fmtDay(first)}</span>`;
    } else {
      const cl = e.cmp && e.cmp > e.price ? Math.round(((e.cmp - e.price) / e.cmp) * 100) : 0;
      tip.innerHTML =
        `<b>${fmtDay(t)}, ${fmtTime(t)}</b><br>${fmtMoney(e.price)}` +
        (e.cmp && e.cmp > e.price ? ` &nbsp;<s>${fmtMoney(e.cmp)}</s> (-${cl}%)` : "") +
        (e.avail === false ? "<br>Sold out" : "") +
        (e.src ? `<br><span style="opacity:.8">approximate (${e.src})</span>` : "");
    }
    tip.classList.add("show");
    const w = tip.offsetWidth;
    let left = x + 10;
    if (left + w > rect.width) left = x - w - 10;
    tip.style.left = Math.max(2, left) + "px";
    tip.style.top = "6px";
  });
  canvas.addEventListener("mouseleave", () => {
    tip.classList.remove("show");
    redraw();
  });

  /* ---- actions ---- */
  $("#openBtn", root).onclick = () => openProductPage(p.handle);
  $("#shareBtn", root).onclick = async () => {
    try {
      const blob = await canvasToBlob(makeShareCard(v, ctx.now));
      downloadBlob(`audionic-price-check-${p.handle}.png`, blob);
      toast("Share card saved to your downloads.");
    } catch (e) {
      toast("Could not create the card: " + e.message, "error");
    }
  };
  const bf = $("#backfillBtn", root);
  bf.onclick = async () => {
    if (!ctx.settings.backfill) return toast('Turn on "Archive backfill" in Settings first.');
    let ok = false;
    try {
      ok = await chrome.permissions.request({ origins: ["https://web.archive.org/*"] });
    } catch (e) {
      return toast(e.message, "error");
    }
    if (!ok) return toast("Permission for web.archive.org was not granted.", "error");
    bf.disabled = true;
    bf.textContent = "Searching the Internet Archive…";
    try {
      const r = await send("backfill", { productId: p.id, variantId: variant.id });
      toast(
        r.found
          ? `Added ${r.found} approximate price points from archived copies.`
          : r.captures
          ? `Checked ${r.tried} archived copies but could not read prices from them.`
          : "The Internet Archive has no saved copies of this page."
      );
      await ctx.go("product", { productId: p.id, variantId: variant.id });
    } catch (e) {
      toast(e.message, "error");
      bf.disabled = false;
      bf.textContent = "Backfill from Internet Archive";
    }
  };

  /* ---- watch box ---- */
  renderWatch($("#watchBox", root), ctx, v);

  /* ---- notes ---- */
  const notes = $("#notes", root);
  const save = debounce(async () => {
    const cur = (await chrome.storage.local.get("notes")).notes || {};
    const next = { ...cur };
    if (notes.value.trim()) next[p.id] = notes.value;
    else delete next[p.id];
    await setState({ notes: next });
  }, 500);
  notes.addEventListener("input", save);
}

function urgencyHtml(v) {
  const u = v.urgency;
  if (!u || (!Object.keys(u.tactics || {}).length && !u.countdown)) return "";
  const chips = Object.keys(u.tactics || {}).map((n) => `<span class="chip">${esc(n)}</span>`).join("");
  let cd = "";
  if (u.countdown) {
    const c = u.countdown;
    const bits = [];
    bits.push(`A countdown timer was seen on this page (last seen ${fmtAgo(c.last, Date.now())}).`);
    if (c.restarts > 0) bits.push(`It <b>restarted ${c.restarts} time${c.restarts > 1 ? "s" : ""}</b> while the page was open.`);
    if (c.expiredShown) bits.push("It has been showing zero for over an hour, yet the page keeps displaying it.");
    cd = `<p class="small" style="margin-top:8px">${bits.join(" ")}</p>`;
  }
  return `<div class="card"><h3>Urgency tactics seen on this page</h3><div class="chips">${chips}</div>${cd}
    <p class="small muted" style="margin-top:8px">Detected from the page's visible text while you browsed. Best effort, and not every banner is a tactic.</p></div>`;
}

function renderWatch(box, ctx, v) {
  const w = v.watch;
  const variant = v.variant;
  box.innerHTML = `
    <h3>Watchlist</h3>
    <div class="row">
      <div class="grow"><input type="number" id="target" min="0" step="1" placeholder="Target price, e.g. ${Math.round(variant.price * 0.9)}" value="${w && w.target ? w.target : ""}" /></div>
      ${w ? `<button class="btn small" id="saveWatch">Save</button><button class="btn ghost small" id="stopWatch">Stop watching</button>` : `<button class="btn orange small" id="addWatch">Add to watchlist</button>`}
    </div>
    <div class="checks">
      <label><input type="checkbox" id="stockA" ${!w || w.stockAlert !== false ? "checked" : ""}/> Back in stock</label>
      <label><input type="checkbox" id="claimA" ${!w || w.claimAlert !== false ? "checked" : ""}/> Discount claim raised without a price drop</label>
    </div>
    <p class="small muted">${w ? "You will get a notification on price drops, when your target is reached, and for the alerts ticked above." : "Add this product to be notified about price drops, your target price, back-in-stock and suspicious discount changes."}</p>`;
  const read = () => {
    const t = parseFloat($("#target", box).value);
    return {
      productId: v.product.id,
      variantId: variant.id,
      target: Number.isFinite(t) && t > 0 ? t : null,
      stockAlert: $("#stockA", box).checked,
      claimAlert: $("#claimA", box).checked,
      addedAt: w ? w.addedAt : Date.now(),
    };
  };
  const write = async (obj) => {
    const cur = (await chrome.storage.local.get("watchlist")).watchlist || {};
    await setState({ watchlist: obj(cur) });
  };
  const add = $("#addWatch", box);
  if (add)
    add.onclick = async () => {
      await write((cur) => ({ ...cur, [variant.id]: read() }));
      toast("Added to your watchlist.");
      ctx.go("product", { productId: v.product.id, variantId: variant.id });
    };
  const sv = $("#saveWatch", box);
  if (sv)
    sv.onclick = async () => {
      await write((cur) => ({ ...cur, [variant.id]: read() }));
      toast("Watchlist entry saved.");
    };
  const stop = $("#stopWatch", box);
  if (stop)
    stop.onclick = async () => {
      await write((cur) => {
        const n = { ...cur };
        delete n[variant.id];
        return n;
      });
      toast("Removed from your watchlist.");
      ctx.go("product", { productId: v.product.id, variantId: variant.id });
    };
}

/* ---------- product picker ---------- */
function renderPicker(root, ctx, hint) {
  const products = Object.values(ctx.state.catalog).filter((p) => !p.delisted);
  const claim = (p) => {
    const best = p.variants.find((x) => x.cmp && x.cmp > x.price);
    return best ? (best.cmp - best.price) / best.cmp : 0;
  };
  const priceOf = (p) => {
    const vs = p.variants.filter((x) => x.avail);
    const pool = vs.length ? vs : p.variants;
    return Math.min(...pool.map((x) => x.price));
  };
  root.innerHTML = `
    <div class="card">
      <h3>Find a product</h3>
      <p class="small muted" style="margin-bottom:8px">${esc(hint)}</p>
      <input type="text" id="q" placeholder="Search ${products.length} Audionic products…" autocomplete="off" />
    </div>
    <div class="card" id="results"></div>`;
  const q = $("#q", root);
  const results = $("#results", root);
  const show = () => {
    const term = q.value.trim().toLowerCase();
    let list = products;
    if (term) list = products.filter((p) => p.title.toLowerCase().includes(term) || (p.tags || []).some((t) => t.toLowerCase().includes(term)));
    else list = [...products].sort((a, b) => claim(b) - claim(a));
    list = list.slice(0, 12);
    results.innerHTML = list.length
      ? (term ? "" : `<h3>Biggest advertised discounts</h3>`) +
        list
          .map(
            (p) => `<div class="item click" data-id="${p.id}">
              <div class="grow"><div class="title ellipsis">${esc(p.title)}</div>
              <div class="sub">${fmtMoney(priceOf(p))}${claim(p) > 0 ? ` · <span style="color:var(--orange-d);font-weight:700">-${Math.round(claim(p) * 100)}% claimed</span>` : ""}</div></div>
              <span class="muted">›</span></div>`
          )
          .join("")
      : `<p class="muted">No product matches “${esc(q.value)}”.</p>`;
  };
  q.addEventListener("input", show);
  results.addEventListener("click", (e) => {
    const it = e.target.closest(".item[data-id]");
    if (it) ctx.go("product", { productId: Number(it.dataset.id) });
  });
  show();
  q.focus();
}
