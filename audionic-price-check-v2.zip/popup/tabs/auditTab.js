// Sale Audit tab: every Audionic product, claimed vs real discount, sortable and filterable.
import { buildAuditRows, summarizeRows, fakestFirst } from "../../lib/views.js";
import { fmtMoney, fmtPct, esc } from "../../lib/utils.js";
import { badge, $ } from "../ui.js";

const SEG = [
  ["FAKE", "Fake-looking", "#E8590C"],
  ["MISLEADING", "Misleading", "#FF7A1A"],
  ["REAL", "Real deal", "#1E5BFF"],
  ["COLLECTING", "Collecting data", "#9DBBFF"],
  ["NO_CLAIM", "No claim", "#8AA0C4"],
];

const filters = { q: "", verdict: "all", avail: "all", tag: "all", sort: "fakest", limit: 60 };

const SORTS = {
  fakest: fakestFirst,
  claimed: (a, b) => b.audit.claimedPct - a.audit.claimedPct,
  realLow: (a, b) => a.audit.realPct - b.audit.realPct,
  priceLow: (a, b) => a.price - b.price,
  priceHigh: (a, b) => b.price - a.price,
  name: (a, b) => a.title.localeCompare(b.title),
};

export async function render(root, ctx) {
  const rows = buildAuditRows(ctx.state, ctx.now);
  const sum = summarizeRows(rows);
  const tags = [...new Set(rows.flatMap((r) => r.tags))].sort((a, b) => a.localeCompare(b));

  const segs = SEG.map(([k, label, color]) => ({ k, label, color, n: sum.counts[k] || 0 })).filter((s) => s.n > 0);
  const total = Math.max(1, sum.total);

  root.innerHTML = `
    <div class="sumgrid">
      <div class="sum"><span>Showing a discount</span><b>${sum.claimers} <small>of ${sum.total}</small></b><small>products with a crossed-out price</small></div>
      <div class="sum"><span>Average claimed</span><b>${fmtPct(sum.avgClaimed)}</b><small>across those ${sum.claimers}</small></div>
      <div class="sum"><span>Average real</span><b>${fmtPct(sum.avgReal)}</b><small>${sum.judged ? `on ${sum.judged} judged products` : "needs more tracked days"}</small></div>
      <div class="sum ${sum.flaggedPct ? "hot" : ""}"><span>Flagged</span><b>${sum.flaggedPct === null ? "—" : fmtPct(sum.flaggedPct)}</b><small>${sum.judged ? "misleading or fake-looking" : "no verdicts yet"}</small></div>
    </div>
    <div class="card">
      <h3>Verdicts across the store</h3>
      <div class="stack">${segs.map((s) => `<i title="${s.label}: ${s.n}" style="width:${(s.n / total) * 100}%;background:${s.color}"></i>`).join("")}</div>
      <div class="legend">${segs.map((s) => `<span><span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${s.color};margin-right:4px"></span>${s.label} ${s.n}</span>`).join("")}</div>
    </div>
    <div class="filters">
      <input class="full" type="text" id="fq" placeholder="Search products…" value="${esc(filters.q)}" />
      <select id="fv">
        <option value="all">All verdicts</option>
        <option value="FAKE">Fake-looking</option><option value="MISLEADING">Misleading</option><option value="REAL">Real deal</option>
        <option value="COLLECTING">Collecting data</option><option value="NO_CLAIM">No discount claimed</option>
      </select>
      <select id="fa"><option value="all">In stock or sold out</option><option value="in">In stock only</option><option value="out">Sold out only</option></select>
      <select id="ft"><option value="all">All tags</option>${tags.map((t) => `<option value="${esc(t)}">${esc(t)}</option>`).join("")}</select>
      <select id="fs">
        <option value="fakest">Fakest first</option><option value="claimed">Biggest claim</option><option value="realLow">Smallest real discount</option>
        <option value="priceLow">Price: low to high</option><option value="priceHigh">Price: high to low</option><option value="name">Name</option>
      </select>
    </div>
    <div class="card" id="list"></div>`;

  $("#fv", root).value = filters.verdict;
  $("#fa", root).value = filters.avail;
  $("#ft", root).value = filters.tag;
  $("#fs", root).value = filters.sort;

  const list = $("#list", root);
  const draw = () => {
    let r = rows;
    const q = filters.q.trim().toLowerCase();
    if (q) r = r.filter((x) => x.title.toLowerCase().includes(q));
    if (filters.verdict !== "all") r = r.filter((x) => x.audit.verdict === filters.verdict);
    if (filters.avail === "in") r = r.filter((x) => x.avail);
    if (filters.avail === "out") r = r.filter((x) => !x.avail);
    if (filters.tag !== "all") r = r.filter((x) => x.tags.includes(filters.tag));
    r = [...r].sort(SORTS[filters.sort] || fakestFirst);
    const shown = r.slice(0, filters.limit);
    list.innerHTML = r.length
      ? `<h3>${r.length} product${r.length === 1 ? "" : "s"}</h3>` +
        shown
          .map(
            (x) => `<div class="item click" data-id="${x.productId}" data-vid="${x.variantId}">
              <div class="grow"><div class="title ellipsis">${esc(x.title)}</div>
              <div class="sub">${fmtMoney(x.price)}${x.audit.claimedPct > 0 ? ` · claimed <b style="color:var(--orange-d)">${fmtPct(x.audit.claimedPct)}</b> · real <b style="color:var(--blue)">${fmtPct(x.audit.realPct)}</b>` : ""}${x.avail ? "" : " · sold out"}</div></div>
              ${badge(x.audit)}</div>`
          )
          .join("") +
        (r.length > shown.length ? `<div style="text-align:center;margin-top:8px"><button class="btn ghost small" id="more">Show ${Math.min(60, r.length - shown.length)} more</button></div>` : "")
      : `<div class="empty">No products match these filters.</div>`;
  };
  draw();

  const bind = (id, key) =>
    $(id, root).addEventListener(key === "q" ? "input" : "change", (e) => {
      filters[key] = e.target.value;
      filters.limit = 60;
      draw();
    });
  bind("#fq", "q");
  bind("#fv", "verdict");
  bind("#fa", "avail");
  bind("#ft", "tag");
  bind("#fs", "sort");

  list.addEventListener("click", (e) => {
    if (e.target.id === "more") {
      filters.limit += 60;
      return draw();
    }
    const it = e.target.closest(".item[data-id]");
    if (it) ctx.go("product", { productId: Number(it.dataset.id), variantId: Number(it.dataset.vid) });
  });
}
