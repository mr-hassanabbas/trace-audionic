// History tab: change log, store-wide sale events, and data export / import.
import { fmtMoney, fmtPct, fmtDateTime, fmtDayYear, esc } from "../../lib/utils.js";
import { send, toast, download, toCsv, $, $$ } from "../ui.js";

const f = { type: "all", q: "", limit: 80 };

function describe(entry) {
  switch (entry.kind) {
    case "change":
      return entry.changes.map((c) => {
        if (c.field === "price") {
          const pct = c.from ? (c.to - c.from) / c.from : 0;
          return `Price ${fmtMoney(c.from)} → <b>${fmtMoney(c.to)}</b> <span class="${pct < 0 ? "" : "muted"}" style="color:${pct < 0 ? "var(--blue)" : "var(--orange-d)"};font-weight:700">(${pct > 0 ? "+" : ""}${fmtPct(pct, 0)})</span>`;
        }
        if (c.field === "compare") return `Crossed-out price ${c.from ? fmtMoney(c.from) : "none"} → <b>${c.to ? fmtMoney(c.to) : "none"}</b>`;
        if (c.field === "stock") return c.to ? "Back in stock" : "Went out of stock";
        return esc(c.field);
      });
    case "new":
      return ["New product listed"];
    case "relisted":
      return ["Listed again"];
    case "delisted":
      return ["No longer listed on the store"];
    case "tags": {
      const c = entry.changes[0];
      return [`Tags: ${esc((c.from || []).join(", ") || "none")} → <b>${esc((c.to || []).join(", ") || "none")}</b>`];
    }
    default:
      return [esc(entry.kind)];
  }
}

function matchesType(entry) {
  if (f.type === "all") return true;
  if (f.type === "price") return entry.kind === "change" && entry.changes.some((c) => c.field === "price");
  if (f.type === "compare") return entry.kind === "change" && entry.changes.some((c) => c.field === "compare");
  if (f.type === "stock") return entry.kind === "change" && entry.changes.some((c) => c.field === "stock");
  return entry.kind === f.type;
}

export async function render(root, ctx) {
  const st = ctx.state;
  const log = [...st.log].reverse();
  const events = [...st.events].sort((a, b) => b.t - a.t);
  const today = new Date().toISOString().slice(0, 10);

  root.innerHTML = `
    <div class="card">
      <h3>Store-wide sale events</h3>
      <p class="small muted" style="margin-bottom:6px">Marked as dotted lines on every price chart. Detected automatically when many prices change at once, or add your own (for example "11.11 Sale").</p>
      <div id="events">${
        events.length
          ? events
              .map(
                (e) => `<div class="row" style="margin:5px 0" data-id="${e.id}">
                  <span class="small muted" style="width:78px;flex:none">${fmtDayYear(e.t)}</span>
                  <input type="text" class="evname" value="${esc(e.name)}" maxlength="60" />
                  ${e.auto ? `<span class="tag" title="${e.changed} of ${e.total} prices changed">auto</span>` : ""}
                  <button class="btn ghost small evdel" title="Delete">✕</button></div>`
              )
              .join("")
          : `<p class="small muted">No events yet.</p>`
      }</div>
      <div class="row" style="margin-top:8px">
        <input type="date" id="evdate" value="${today}" style="width:128px" />
        <input type="text" id="evnew" placeholder="Event name" maxlength="60" />
        <button class="btn small" id="evadd">Add</button>
      </div>
    </div>

    <div class="card">
      <div class="row between"><h3 style="margin:0">Change log</h3><span class="small muted">${st.log.length} entries</span></div>
      <div class="filters" style="margin-top:8px">
        <select id="lt">
          <option value="all">All changes</option><option value="price">Price changes</option><option value="compare">Crossed-out price changes</option>
          <option value="stock">Stock changes</option><option value="new">New products</option><option value="delisted">Delisted</option><option value="tags">Tag changes</option>
        </select>
        <input type="text" id="lq" placeholder="Search product…" value="${esc(f.q)}" />
      </div>
      <div id="loglist"></div>
    </div>

    <div class="card">
      <h3>Export &amp; import</h3>
      <div class="actions">
        <button class="btn ghost small" id="exPrices">Price history CSV</button>
        <button class="btn ghost small" id="exLog">Change log CSV</button>
        <button class="btn ghost small" id="exJson">Full backup (JSON)</button>
        <button class="btn ghost small" id="imp">Import backup…</button>
        <input type="file" id="impFile" accept="application/json,.json" hidden />
      </div>
      <p class="small muted" style="margin-top:6px">Importing merges the backup with what you already have. Nothing is overwritten.</p>
    </div>`;

  $("#lt", root).value = f.type;

  /* ----- log ----- */
  const list = $("#loglist", root);
  const draw = () => {
    const q = f.q.trim().toLowerCase();
    const r = log.filter((e) => matchesType(e) && (!q || (e.title || "").toLowerCase().includes(q)));
    const shown = r.slice(0, f.limit);
    list.innerHTML = r.length
      ? shown
          .map(
            (e) => `<div class="item ${e.productId ? "click" : ""}" data-id="${e.productId || ""}" data-vid="${e.variantId || ""}">
              <div class="grow"><div class="title ellipsis">${esc(e.title || "")}${e.variantTitle && e.variantTitle !== "Default" ? ` <span class="muted">· ${esc(e.variantTitle)}</span>` : ""}</div>
              ${describe(e).map((l) => `<div class="sub">${l}</div>`).join("")}</div>
              <span class="small muted" style="text-align:right;flex:none">${fmtDateTime(e.t)}</span></div>`
          )
          .join("") + (r.length > shown.length ? `<div style="text-align:center;margin-top:8px"><button class="btn ghost small" id="more">Show more</button></div>` : "")
      : `<p class="small muted" style="padding:8px 0">${st.log.length ? "Nothing matches these filters." : "No changes recorded yet. Changes appear here after the extension sees a price, crossed-out price or stock change."}</p>`;
  };
  draw();
  $("#lt", root).addEventListener("change", (e) => {
    f.type = e.target.value;
    f.limit = 80;
    draw();
  });
  $("#lq", root).addEventListener("input", (e) => {
    f.q = e.target.value;
    f.limit = 80;
    draw();
  });
  list.addEventListener("click", (e) => {
    if (e.target.id === "more") {
      f.limit += 80;
      return draw();
    }
    const it = e.target.closest(".item[data-id]");
    if (it && it.dataset.id) ctx.go("product", { productId: Number(it.dataset.id), variantId: it.dataset.vid ? Number(it.dataset.vid) : null });
  });

  /* ----- events ----- */
  $$(".evname", root).forEach((inp) =>
    inp.addEventListener("change", async () => {
      try {
        await send("editEvent", { id: inp.closest("[data-id]").dataset.id, name: inp.value.trim() || "Sale event" });
        toast("Event renamed.");
      } catch (e) {
        toast(e.message, "error");
      }
    })
  );
  $$(".evdel", root).forEach((b) =>
    b.addEventListener("click", async () => {
      await send("deleteEvent", { id: b.closest("[data-id]").dataset.id });
      ctx.go("history");
    })
  );
  $("#evadd", root).addEventListener("click", async () => {
    const name = $("#evnew", root).value.trim();
    const d = $("#evdate", root).value;
    if (!name) return toast("Give the event a name first.");
    const t = d ? new Date(d + "T12:00:00").getTime() : Date.now();
    await send("addEvent", { t, name });
    ctx.go("history");
  });

  /* ----- export / import ----- */
  const name = (p, v) => (p ? p.title : "") + (v && v.title && v.title !== "Default" ? ` (${v.title})` : "");
  $("#exPrices", root).addEventListener("click", () => {
    const rows = [["product", "variant", "handle", "variant_id", "date_iso", "price_pkr", "compare_at_pkr", "available", "source"]];
    for (const p of Object.values(st.catalog))
      for (const v of p.variants)
        for (const e of st.history[v.id] || [])
          rows.push([p.title, v.title, p.handle, v.id, new Date(e.t).toISOString(), e.price, e.cmp ?? "", e.avail == null ? "" : e.avail ? 1 : 0, e.src || "tracked"]);
    download("audionic-price-history.csv", toCsv(rows), "text/csv");
    toast(`Exported ${rows.length - 1} price points.`);
  });
  $("#exLog", root).addEventListener("click", () => {
    const rows = [["date_iso", "kind", "product", "variant", "field", "from", "to"]];
    for (const e of st.log) {
      if (e.changes) for (const c of e.changes) rows.push([new Date(e.t).toISOString(), e.kind, e.title, e.variantTitle || "", c.field, Array.isArray(c.from) ? c.from.join("|") : c.from ?? "", Array.isArray(c.to) ? c.to.join("|") : c.to ?? ""]);
      else rows.push([new Date(e.t).toISOString(), e.kind, e.title, "", "", "", ""]);
    }
    download("audionic-change-log.csv", toCsv(rows), "text/csv");
    toast(`Exported ${rows.length - 1} log rows.`);
  });
  $("#exJson", root).addEventListener("click", () => {
    const data = { catalog: st.catalog, history: st.history, log: st.log, events: st.events, watchlist: st.watchlist, notes: st.notes, urgency: st.urgency, settings: st.settings };
    download(`audionic-price-check-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: "audionic-price-check", version: 1, exportedAt: new Date().toISOString(), data }), "application/json");
    toast("Backup saved to your downloads.");
  });
  const file = $("#impFile", root);
  $("#imp", root).addEventListener("click", () => file.click());
  file.addEventListener("change", async () => {
    const fl = file.files[0];
    if (!fl) return;
    try {
      const payload = JSON.parse(await fl.text());
      const r = await send("importData", { payload });
      toast(`Imported. Now tracking ${r.products} products.`);
      ctx.go("history");
    } catch (e) {
      toast(e.message.includes("JSON") ? "That file is not valid JSON." : e.message, "error");
    }
  });
}
