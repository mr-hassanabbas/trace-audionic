// Popup bootstrap: header, tab switching, first-run waiting screen.
import { getState } from "../lib/storage.js";
import { fmtAgo, esc } from "../lib/utils.js";
import { send, toast, applyTheme, $, $$ } from "./ui.js";
import * as productTab from "./tabs/product.js";
import * as watchlistTab from "./tabs/watchlist.js";
import * as auditTab from "./tabs/auditTab.js";
import * as historyTab from "./tabs/historyTab.js";
import * as settingsTab from "./tabs/settingsTab.js";

const TABS = { product: productTab, watchlist: watchlistTab, audit: auditTab, history: historyTab, settings: settingsTab };
const view = $("#view");
let current = "product";
let pollTimer = null;

const ctx = {
  state: null,
  settings: null,
  now: Date.now(),
  go,
  toast,
  send,
};

async function loadState() {
  ctx.state = await getState();
  ctx.settings = ctx.state.settings;
  ctx.now = Date.now();
  applyTheme(ctx.settings.theme);
}

function renderSyncLine(meta) {
  const el = $("#syncLine");
  el.classList.remove("err");
  if (meta.lastSyncOk === false && meta.lastError) {
    el.classList.add("err");
    el.textContent = "Last check failed: " + meta.lastError;
  } else if (meta.lastSync) {
    el.textContent = `Last check ${fmtAgo(meta.lastSync)} · ${meta.productCount || 0} products tracked`;
    if (meta.lastError) el.classList.add("err");
  } else {
    el.textContent = "Waiting for the first check…";
  }
}

function renderWaiting(meta) {
  const failed = meta.lastSyncOk === false && meta.lastError;
  view.innerHTML = `<div class="empty">
    <h2>${failed ? "Couldn't load the Audionic catalogue" : "Loading the Audionic catalogue…"}</h2>
    <p>${failed ? esc(meta.lastError) : "This takes a few seconds the first time. Price tracking starts as soon as it finishes."}</p>
    ${failed ? `<button class="btn orange" id="retry" style="margin-top:12px">Try again</button>` : `<div class="progress"><i></i></div>`}
  </div>`;
  const retry = $("#retry", view);
  if (retry) retry.onclick = () => $("#syncBtn").click();
  pollTimer = setTimeout(async () => {
    const st = await getState(["meta", "catalog"]);
    if (Object.keys(st.catalog).length) go(current);
    else {
      renderSyncLine(st.meta);
      renderWaiting(st.meta);
    }
  }, 1500);
}

async function go(tab, opts = {}) {
  const switching = tab !== current;
  current = tab;
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  clearTimeout(pollTimer);
  view.onclick = null; // tabs set their own container handlers; never let them stack up
  view.onchange = null;
  await loadState();
  renderSyncLine(ctx.state.meta);
  const hasData = Object.keys(ctx.state.catalog).length > 0;
  if (!hasData && tab !== "settings" && tab !== "history") return renderWaiting(ctx.state.meta);
  try {
    await TABS[tab].render(view, ctx, opts);
    if (switching || opts.productId) view.scrollTop = 0;
  } catch (e) {
    console.error(e);
    view.innerHTML = `<div class="empty"><h2>Something went wrong</h2><p>${esc(e.message)}</p></div>`;
  }
}

$("#tabs").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-tab]");
  if (b) go(b.dataset.tab);
});

const syncBtn = $("#syncBtn");
syncBtn.addEventListener("click", async () => {
  if (syncBtn.classList.contains("spin")) return;
  syncBtn.classList.add("spin");
  $("#syncLine").textContent = "Checking Audionic prices…";
  try {
    const r = await send("syncNow");
    toast(r.firstSync ? `Loaded ${r.products} products. Tracking starts now.` : r.changedVariants ? `Checked ${r.products} products: ${r.changedVariants} price or stock changes found.` : `Checked ${r.products} products: no changes.`);
  } catch (e) {
    toast(e.message, "error");
  } finally {
    syncBtn.classList.remove("spin");
    await go(current);
  }
});

(async () => {
  send("ensureFresh").catch(() => {});
  await go("product");
})();
