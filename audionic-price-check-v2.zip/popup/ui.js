// Small UI helpers shared by the popup tabs.
import { esc } from "../lib/utils.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Ask the background service worker to do something. Rejects with a readable Error. */
export function send(type, payload = {}) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({ type, ...payload }, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error("No response from the extension background."));
        if (!res.ok) return reject(new Error(res.error || "Something went wrong."));
        resolve(res.data);
      });
    } catch (e) {
      reject(e);
    }
  });
}

let toastTimer;
export function toast(msg, kind = "info") {
  let el = document.getElementById("toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "toast";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.className = "toast show " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), kind === "error" ? 5000 : 2800);
}

export function badge(audit) {
  const m = audit.meta;
  return `<span class="badge v-${m.cls}">${esc(m.label)}</span>`;
}

export function applyTheme(setting) {
  const resolved = setting === "auto" ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : setting === "dark" ? "dark" : "light";
  document.body.dataset.theme = resolved;
}

export function themeName() {
  return document.body.dataset.theme === "dark" ? "dark" : "light";
}

export async function activeTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab && tab.url ? tab.url : null;
  } catch {
    return null;
  }
}

export function download(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: mime + ";charset=utf-8" });
  downloadBlob(filename, blob);
}

export function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function csvCell(v) {
  const s = v === null || v === undefined ? "" : String(v);
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

export function toCsv(rows) {
  return rows.map((r) => r.map(csvCell).join(",")).join("\r\n");
}

export function openProductPage(handle) {
  chrome.tabs.create({ url: `https://audionic.co/products/${handle}` });
}
