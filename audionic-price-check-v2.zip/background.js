// Service worker: scheduled catalogue syncs (chrome.alarms), notifications, and the message router
// used by the popup and the on-page content script. All writes to shared data go through `locked()`
// so a sync and a user edit can never overwrite each other.
import { getState, setState, getSettings, KEYS } from "./lib/storage.js";
import { fetchCatalog, fetchShared } from "./lib/api.js";
import { applyCatalog, pruneHistory, mergeSharedInto, mergeImport } from "./lib/sync.js";
import { fetchArchiveSnapshots } from "./lib/archive.js";
import { mergeSeries } from "./lib/history.js";
import { overlayModel, verdictsForHandles, findByHandle, pickPrimaryVariant } from "./lib/views.js";
import { HOUR, MIN, uid } from "./lib/utils.js";

/* ---------- tiny mutex ---------- */
let chain = Promise.resolve();
function locked(fn) {
  const run = chain.then(fn);
  chain = run.then(
    () => {},
    () => {}
  );
  return run;
}

/* ---------- sync ---------- */
let syncing = null;

export function syncNow(reason = "manual") {
  if (syncing) return syncing;
  syncing = locked(() => doSync(reason)).finally(() => {
    syncing = null;
  });
  return syncing;
}

async function doSync(reason) {
  const state = await getState(["settings", "catalog", "history", "log", "events", "watchlist", "meta"]);
  const now = Date.now();
  let result;
  try {
    result = await fetchCatalog({});
  } catch (e) {
    await setState({ meta: { ...state.meta, lastAttempt: now, lastSyncOk: false, lastError: friendlyError(e) } });
    throw e;
  }
  if (!result.products.length) {
    const err = new Error("The store returned no products (it may be blocking requests or has changed).");
    await setState({ meta: { ...state.meta, lastAttempt: now, lastSyncOk: false, lastError: err.message } });
    throw err;
  }

  const applied = applyCatalog(state, result.products, now, { complete: result.complete });
  const history = pruneHistory(applied.history, state.settings.retentionDays, now);
  const meta = {
    ...state.meta,
    lastSync: now,
    lastAttempt: now,
    lastSyncOk: true,
    lastError: result.complete ? null : `Partial download (${result.error || "unknown error"}). Existing data was kept.`,
    syncCount: (state.meta.syncCount || 0) + 1,
    productCount: result.products.length,
    variantCount: applied.stats.variants,
    lastChanged: applied.stats.changedVariants,
    lastReason: reason,
  };
  await setState({ catalog: applied.catalog, history, log: applied.log, events: applied.events, meta });

  if (state.settings.notifications && applied.alerts.length) await notify(applied.alerts);

  // Optional shared history from the collector
  if (state.settings.sharedEnabled && state.settings.sharedUrl && (!meta.lastShared || now - meta.lastShared > 6 * HOUR)) {
    try {
      await doMergeShared();
    } catch (e) {
      const m = (await getState(["meta"])).meta;
      await setState({ meta: { ...m, lastSharedError: friendlyError(e) } });
    }
  }
  return { ...applied.stats, complete: result.complete };
}

function friendlyError(e) {
  const m = String((e && e.message) || e);
  if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return "Could not reach audionic.co (check your internet connection).";
  if (/HTTP 403|HTTP 401|HTTP 404/.test(m)) return `audionic.co refused the request (${m}). The store may have disabled its public product feed.`;
  return m;
}

async function notify(alerts) {
  const shown = alerts.slice(0, 4);
  for (const a of shown) {
    chrome.notifications.create(`apc:${a.handle || "-"}:${a.id}`, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: a.title,
      message: a.message,
      priority: 1,
    });
  }
  if (alerts.length > shown.length) {
    chrome.notifications.create(`apc:-:more-${Date.now()}`, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Audionic Price Check",
      message: `${alerts.length - shown.length} more alerts. Open the extension to see everything.`,
    });
  }
}

chrome.notifications.onClicked.addListener((id) => {
  const m = /^apc:([^:]+):/.exec(id);
  if (m && m[1] !== "-") chrome.tabs.create({ url: `https://audionic.co/products/${m[1]}` });
  chrome.notifications.clear(id);
});

/* ---------- alarms ---------- */
async function ensureAlarm() {
  const s = await getSettings();
  const period = Math.max(30, Number(s.intervalMin) || 360);
  const a = await chrome.alarms.get("sync");
  if (!a || a.periodInMinutes !== period) chrome.alarms.create("sync", { periodInMinutes: period, delayInMinutes: 1 });
}

async function maybeSync(reason) {
  const st = await getState(["settings", "meta"]);
  const every = Math.max(30, Number(st.settings.intervalMin) || 360) * MIN;
  if (!st.meta.lastSync || Date.now() - st.meta.lastSync > every) {
    syncNow(reason).catch(() => {});
    return true;
  }
  return false;
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "sync") syncNow("alarm").catch(() => {});
});

chrome.runtime.onInstalled.addListener(async () => {
  await ensureAlarm();
  syncNow("install").catch(() => {});
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureAlarm();
  maybeSync("startup");
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.settings) return;
  const o = changes.settings.oldValue || {};
  const n = changes.settings.newValue || {};
  if (o.intervalMin !== n.intervalMin) ensureAlarm();
});

/* ---------- shared history / backfill / import ---------- */
async function doMergeShared() {
  const st = await getState(["settings", "catalog", "history", "meta"]);
  if (!st.settings.sharedUrl) throw new Error("No shared history URL is set.");
  const json = await fetchShared(st.settings.sharedUrl);
  const { history, merged } = mergeSharedInto(st.history, st.catalog, json);
  await setState({
    history,
    meta: { ...st.meta, lastShared: Date.now(), lastSharedMerged: merged, lastSharedGenerated: json.generated || null, lastSharedError: null },
  });
  return { merged, generated: json.generated || null };
}

async function doBackfill({ productId, variantId }) {
  const st = await getState(["catalog", "history"]);
  const p = st.catalog[productId];
  if (!p) throw new Error("Product not found.");
  const granted = await chrome.permissions.contains({ origins: ["https://web.archive.org/*"] });
  if (!granted) throw new Error("Permission for web.archive.org has not been granted.");
  const v = (variantId && p.variants.find((x) => x.id === variantId)) || pickPrimaryVariant(p);
  const r = await fetchArchiveSnapshots(p.handle, {});
  if (r.entries.length) {
    const history = { ...st.history, [v.id]: mergeSeries(st.history[v.id] || [], r.entries) };
    await setState({ history });
  }
  return { captures: r.captures, tried: r.tried, found: r.found };
}

/* ---------- urgency reports from the content script ---------- */
async function doUrgency({ handle, tactics = [], countdown = null }) {
  const st = await getState(["catalog", "urgency"]);
  const p = findByHandle(st.catalog, handle);
  if (!p) return null;
  const now = Date.now();
  const u = { tactics: {}, countdown: null, ...(st.urgency[p.id] || {}) };
  u.tactics = { ...u.tactics };
  for (const name of tactics) {
    const cur = u.tactics[name] || { first: now, last: now, count: 0 };
    u.tactics[name] = { first: cur.first, last: now, count: cur.count + 1 };
  }
  if (countdown && Number.isFinite(countdown.remaining)) {
    const cd = u.countdown ? { ...u.countdown } : { seen: true, first: now, samples: [], restarts: 0, zeroSince: null, expiredShown: false };
    const prev = cd.samples[cd.samples.length - 1];
    if (prev) {
      const expected = Math.max(0, prev.r - (now - prev.t) / 1000);
      if (countdown.remaining > expected + 60) cd.restarts = (cd.restarts || 0) + 1;
    }
    if (countdown.remaining === 0) {
      if (!cd.zeroSince) cd.zeroSince = now;
    } else {
      cd.zeroSince = null;
    }
    cd.expiredShown = !!(cd.zeroSince && now - cd.zeroSince > HOUR);
    cd.last = now;
    cd.lastRemaining = countdown.remaining;
    cd.samples = [...cd.samples, { t: now, r: countdown.remaining }].slice(-40);
    u.countdown = cd;
  }
  await setState({ urgency: { ...st.urgency, [p.id]: u } });
  return true;
}

/* ---------- badge ---------- */
const BADGE_COLORS = { REAL: "#1E5BFF", MISLEADING: "#FF7A1A", FAKE: "#E8590C", COLLECTING: "#9DBBFF", NO_CLAIM: "#8AA0C4" };
async function setBadge(tabId, verdict, text) {
  if (tabId == null) return;
  try {
    await chrome.action.setBadgeText({ tabId, text: text || "" });
    if (text) {
      await chrome.action.setBadgeBackgroundColor({ tabId, color: BADGE_COLORS[verdict] || "#1E5BFF" });
      if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ tabId, color: "#FFFFFF" });
    }
  } catch {
    /* tab may be gone */
  }
}

/* ---------- message router ---------- */
const handlers = {
  async ensureFresh() {
    return { started: await maybeSync("visit") };
  },
  async syncNow() {
    return await syncNow("manual");
  },
  async getStatus() {
    const { meta } = await getState(["meta"]);
    return { ...meta, syncing: !!syncing };
  },
  async contentSettings() {
    const s = await getSettings();
    return { overlay: s.overlay, productDots: s.productDots, urgency: s.urgency };
  },
  async overlay({ handle }) {
    const state = await getState();
    return overlayModel(state, handle);
  },
  async verdicts({ handles }) {
    const state = await getState(["settings", "catalog", "history"]);
    return verdictsForHandles(state, handles || []);
  },
  async badge({ verdict, text }, sender) {
    await setBadge(sender && sender.tab ? sender.tab.id : null, verdict, text);
    return true;
  },
  async urgency(payload) {
    return locked(() => doUrgency(payload));
  },
  async openPopup() {
    try {
      await chrome.action.openPopup();
      return { opened: true };
    } catch {
      return { opened: false };
    }
  },
  async addEvent({ t, name }) {
    return locked(async () => {
      const { events } = await getState(["events"]);
      const ev = { id: uid(), t: Number(t) || Date.now(), name: String(name || "Sale event").slice(0, 60), auto: false };
      const next = [...events, ev].sort((a, b) => a.t - b.t);
      await setState({ events: next });
      return ev;
    });
  },
  async editEvent({ id, name }) {
    return locked(async () => {
      const { events } = await getState(["events"]);
      await setState({ events: events.map((e) => (e.id === id ? { ...e, name: String(name || "Sale event").slice(0, 60), auto: false } : e)) });
      return true;
    });
  },
  async deleteEvent({ id }) {
    return locked(async () => {
      const { events } = await getState(["events"]);
      await setState({ events: events.filter((e) => e.id !== id) });
      return true;
    });
  },
  async backfill(payload) {
    return locked(() => doBackfill(payload));
  },
  async mergeShared() {
    return locked(() => doMergeShared());
  },
  async importData({ payload }) {
    return locked(async () => {
      if (!payload || payload.app !== "audionic-price-check" || !payload.data) throw new Error("This file is not an Audionic Price Check backup.");
      const st = await getState(["catalog", "history", "log", "events", "watchlist", "notes"]);
      const merged = mergeImport(st, payload);
      await setState(merged);
      return { products: Object.keys(merged.catalog).length, variants: Object.keys(merged.history).length };
    });
  },
  async clearData() {
    return locked(async () => {
      const keep = await chrome.storage.local.get(["settings"]);
      await chrome.storage.local.clear();
      await chrome.storage.local.set(keep);
      return true;
    });
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const h = msg && handlers[msg.type];
  if (!h) return false;
  h(msg, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((e) => sendResponse({ ok: false, error: friendlyError(e) }));
  return true;
});

export { KEYS };
