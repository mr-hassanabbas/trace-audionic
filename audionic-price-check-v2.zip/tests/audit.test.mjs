import test from "node:test";
import assert from "node:assert/strict";
import { computeAudit, DEFAULT_THRESHOLDS } from "../lib/audit.js";
import { DAY } from "../lib/utils.js";

const NOW = Date.UTC(2026, 10, 10, 12, 0, 0);
const d = (daysAgo) => NOW - daysAgo * DAY;
const e = (daysAgo, price, cmp = null, avail = true) => ({ t: d(daysAgo), price, cmp, avail });

test("FAKE-looking sale: price flat at 3,888 vs 9,999 for 60 days", () => {
  const a = computeAudit([e(60, 3888, 9999)], NOW);
  assert.equal(a.verdict, "FAKE");
  assert.ok(Math.abs(a.claimedPct - 0.611) < 0.01);
  assert.equal(a.realPct, 0);
  assert.equal(a.originalChargedDays, 0);
  assert.match(a.reasons.join(" "), /not seen charged/);
});

test("REAL deal: price fell from 6,999 to 3,888 and 6,999 was really charged", () => {
  const a = computeAudit([e(60, 6999, null), e(10, 3888, 6999)], NOW);
  assert.equal(a.verdict, "REAL");
  assert.ok(a.realPct > 0.4);
  assert.ok(a.originalChargedDays > 49);
});

test("MISLEADING: displays 55% off but price only fell ~10%", () => {
  const a = computeAudit([e(60, 5000, null), e(10, 4500, 9999)], NOW);
  assert.equal(a.verdict, "MISLEADING");
  assert.ok(a.realPct > 0.09 && a.realPct < 0.11);
  assert.ok(a.claimedPct > 0.5);
});

test("NO_CLAIM when there is no crossed-out price", () => {
  const a = computeAudit([e(30, 4000, null)], NOW);
  assert.equal(a.verdict, "NO_CLAIM");
});

test("NO_CLAIM when compare-at is not higher than price", () => {
  const a = computeAudit([e(30, 4000, 4000)], NOW);
  assert.equal(a.verdict, "NO_CLAIM");
});

test("COLLECTING with under 3 days of data", () => {
  const a = computeAudit([e(1, 3888, 9999)], NOW);
  assert.equal(a.verdict, "COLLECTING");
  assert.match(a.confidence, /Based on/);
});

test("COLLECTING (not FAKE) for a flat price seen for only 8 days", () => {
  const a = computeAudit([e(8, 3888, 9999)], NOW);
  assert.equal(a.verdict, "COLLECTING");
  assert.match(a.reasons[0], /14 days/);
});

test("raised compare-at without price drop is flagged", () => {
  const a = computeAudit([e(45, 3888, 7999), e(5, 3888, 9999)], NOW);
  assert.equal(a.inflation, true);
  assert.match(a.reasons.join(" "), /raised recently/);
  assert.equal(a.verdict, "FAKE");
});

test("sale stats: times on sale, share of days on sale", () => {
  const a = computeAudit([e(40, 3000, null), e(30, 2500, 3000), e(20, 3000, null), e(10, 2500, 3000)], NOW);
  assert.equal(a.timesOnSale, 2);
  assert.ok(a.saleDayShare > 0.45 && a.saleDayShare < 0.55);
  assert.equal(a.lowest, 2500);
  assert.equal(a.highest, 3000);
});

test("prior-30-day low is reported", () => {
  const a = computeAudit([e(50, 5000, null), e(20, 4000, null), e(5, 4200, 9999)], NOW);
  assert.equal(a.prior30Low, 4000);
});

test("thresholds are configurable (fakeStableDays)", () => {
  const a = computeAudit([e(8, 3888, 9999)], NOW, { fakeStableDays: 7 });
  assert.equal(a.verdict, "FAKE");
});

test("empty series gives NO_DATA", () => {
  assert.equal(computeAudit([], NOW).verdict, "NO_DATA");
});

test("defaults match the spec", () => {
  assert.equal(DEFAULT_THRESHOLDS.fakeStableDays, 14);
  assert.equal(DEFAULT_THRESHOLDS.minDays, 3);
});
