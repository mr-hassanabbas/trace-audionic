import test from "node:test";
import assert from "node:assert/strict";
import { mergeSeries, clipSeries, pruneSeries, valueAt, collapse } from "../lib/history.js";
import { applyCatalog, mergeSharedInto, watchAlerts, pruneHistory } from "../lib/sync.js";
import { normalizeProduct } from "../lib/api.js";
import { parseArchivedHtml, pickEvenly, parseTs } from "../lib/archive.js";
import { stepPath, parseMoney, fmtMoney, handleFromUrl, DAY } from "../lib/utils.js";
import { buildAuditRows, summarizeRows, overlayModel, fakestFirst, pickPrimaryVariant } from "../lib/views.js";
import { thresholdsFromSettings } from "../lib/audit.js";
import { DEFAULT_SETTINGS } from "../lib/storage.js";

const NOW = Date.UTC(2026, 10, 10, 12, 0, 0);

// A real product as returned by https://audionic.co/products.json (trimmed)
const RAW = {
  id: 9384956297372,
  title: "Orchestra Pro Dolby Audio Sound Bar with Wireless Woofer 5.1 Ch",
  handle: "orchestra-pro-dolby-atmos",
  vendor: "Audionic",
  tags: ["MAX5"],
  variants: [{ id: 48261384077468, title: "Default Title", sku: "25529", available: true, price: "74999.00", compare_at_price: "99999.00" }],
  images: [{ src: "https://cdn.shopify.com/x.webp" }],
};

test("normalizeProduct handles Shopify strings and null compare_at", () => {
  const p = normalizeProduct(RAW);
  assert.equal(p.variants[0].price, 74999);
  assert.equal(p.variants[0].cmp, 99999);
  assert.equal(p.variants[0].title, "Default");
  assert.equal(p.image, "https://cdn.shopify.com/x.webp");
  const q = normalizeProduct({ ...RAW, tags: "a, b", variants: [{ id: 1, title: "Red", price: "100.00", compare_at_price: null, available: false }] });
  assert.deepEqual(q.tags, ["a", "b"]);
  assert.equal(q.variants[0].cmp, null);
  assert.equal(q.variants[0].avail, false);
});

test("utils", () => {
  assert.equal(parseMoney("3,888.00"), 3888);
  assert.equal(parseMoney(null), null);
  assert.equal(parseMoney("0.00"), null);
  assert.equal(fmtMoney(3888), "Rs. 3,888");
  assert.equal(handleFromUrl("https://audionic.co/collections/x/products/airbud-500?variant=1"), "airbud-500");
  assert.equal(handleFromUrl("https://audionic.co/"), null);
  const d = stepPath([{ t: 0, v: 5 }, { t: 10, v: 8 }, { t: 20, v: null }, { t: 30, v: 2 }], (t) => t, (v) => v);
  assert.equal(d, "M0.0 5.0H10.0V8.0H20.0M30.0 2.0");
});

test("history: merge, collapse, clip, prune", () => {
  const local = [{ t: 100, price: 10, cmp: null, avail: true }];
  const extra = [
    { t: 10, price: 12, cmp: 20, avail: null, src: "archive" },
    { t: 50, price: 10, cmp: null, avail: null, src: "archive" },
    { t: 100, price: 99, cmp: null, avail: true, src: "shared" },
  ];
  const m = mergeSeries(local, extra);
  assert.deepEqual(m.map((x) => [x.t, x.price]), [[10, 12], [50, 10]]); // t=50 same as local@100 -> collapsed
  assert.equal(valueAt(m, 60).price, 10);
  assert.equal(valueAt(m, 5), null);
  const clipped = clipSeries([{ t: 0, price: 5 }, { t: 50, price: 7 }], 20, 100);
  assert.deepEqual(clipped.map((x) => [x.t, x.price]), [[20, 5], [50, 7], [100, 7]]);
  assert.equal(pruneSeries([{ t: 0, price: 1 }, { t: 50, price: 2 }, { t: 90, price: 3 }], 60).length, 2);
  assert.equal(collapse([{ t: 1, price: 1, cmp: null }, { t: 2, price: 1, cmp: null }]).length, 1);
});

function mkProducts(n, priceFn = () => 1000) {
  return Array.from({ length: n }, (_, i) => ({
    id: i + 1,
    handle: "p" + i,
    title: "Product " + i,
    vendor: "Audionic",
    tags: [],
    image: null,
    variants: [{ id: 1000 + i, title: "Default", sku: "", price: priceFn(i), cmp: 2000, avail: true }],
  }));
}

const baseState = () => ({ settings: { ...DEFAULT_SETTINGS }, catalog: {}, history: {}, log: [], events: [], watchlist: {} });

test("sync: first sync stores history without logging", () => {
  const r = applyCatalog(baseState(), mkProducts(3), NOW, { complete: true });
  assert.equal(Object.keys(r.catalog).length, 3);
  assert.equal(r.history[1000].length, 1);
  assert.equal(r.log.length, 0);
  assert.equal(r.stats.firstSync, true);
});

test("sync: detects price change, logs it and fires watchlist alerts", () => {
  let s = baseState();
  let r = applyCatalog(s, mkProducts(3), NOW, { complete: true });
  s = { ...s, ...r, watchlist: { 1000: { productId: 1, variantId: 1000, target: 900 } } };
  r = applyCatalog(s, mkProducts(3, (i) => (i === 0 ? 800 : 1000)), NOW + DAY, { complete: true });
  assert.equal(r.history[1000].length, 2);
  assert.equal(r.log.length, 1);
  assert.equal(r.log[0].changes[0].field, "price");
  assert.deepEqual(r.log[0].changes[0], { field: "price", from: 1000, to: 800 });
  const titles = r.alerts.map((a) => a.title);
  assert.ok(titles.includes("Target price reached"));
  assert.ok(titles.includes("Price drop"));
});

test("sync: unchanged catalogue adds no history; delisting only when complete", () => {
  let s = baseState();
  let r = applyCatalog(s, mkProducts(3), NOW, {});
  s = { ...s, ...r };
  r = applyCatalog(s, mkProducts(3), NOW + DAY, {});
  assert.equal(r.history[1000].length, 1);
  assert.equal(r.log.length, 0);
  // partial fetch: product 3 missing but not delisted
  r = applyCatalog(s, mkProducts(2), NOW + DAY, { complete: false });
  assert.equal(r.catalog[3].delisted, false);
  r = applyCatalog(s, mkProducts(2), NOW + DAY, { complete: true });
  assert.equal(r.catalog[3].delisted, true);
  assert.equal(r.log.at(-1).kind, "delisted");
});

test("sync: store-wide event when >=30% of the catalogue changes at once", () => {
  let s = baseState();
  let r = applyCatalog(s, mkProducts(40), NOW, {});
  s = { ...s, ...r };
  r = applyCatalog(s, mkProducts(40, (i) => (i < 20 ? 700 : 1000)), NOW + DAY, {});
  assert.equal(r.events.length, 1);
  assert.equal(r.events[0].auto, true);
  assert.equal(r.events[0].changed, 20);
  // small change: no new event
  s = { ...s, ...r };
  r = applyCatalog(s, mkProducts(40, (i) => (i < 20 ? 700 : i === 30 ? 900 : 1000)), NOW + 2 * DAY, {});
  assert.equal(r.events.length, 1);
});

test("watchAlerts: claim increase without price drop and back in stock", () => {
  const w = { variantId: 1, target: null };
  const prod = { title: "X" };
  const a = watchAlerts(w, prod, { price: 1000, cmp: 2000, avail: false }, { t: 1, price: 1000, cmp: 3000, avail: true }, { alertDropPct: 10 });
  assert.deepEqual(a.map((x) => x.title).sort(), ["Back in stock", "Discount claim increased"]);
});

test("shared history merges into known variants only", () => {
  const catalog = { 1: { variants: [{ id: 1000 }] } };
  const json = { variants: { 1000: { pts: [[NOW - 10 * DAY, 1500, 2000, 1], [NOW - 5 * DAY, 1000, 2000, 1]] }, 9999: { pts: [[1, 1, null, 1]] } } };
  const { history, merged } = mergeSharedInto({ 1000: [{ t: NOW, price: 1000, cmp: 2000, avail: true }] }, catalog, json);
  assert.equal(merged, 1);
  assert.deepEqual(history[1000].map((e) => e.price), [1500, 1000]);
  assert.equal(history[9999], undefined);
});

test("pruneHistory keeps the entry in effect at the cutoff", () => {
  const h = pruneHistory({ 1: [{ t: NOW - 100 * DAY, price: 1 }, { t: NOW - 50 * DAY, price: 2 }, { t: NOW - 1 * DAY, price: 3 }] }, 30, NOW);
  assert.deepEqual(h[1].map((e) => e.price), [2, 3]);
});

test("archive parser: embedded JSON (paisa) and visible text", () => {
  const json = '<script>var meta={"product":{"variants":[{"id":1,"price":388800,"name":"x","compare_at_price":999900}]}}</script>';
  assert.deepEqual(parseArchivedHtml(json), { price: 3888, cmp: 9999, method: "json" });
  const txt = "<div><span>Rs.3,888</span> <s>Rs.9,999</s> you saved 61%</div>";
  assert.deepEqual(parseArchivedHtml(txt), { price: 3888, cmp: 9999, method: "text" });
  assert.equal(parseArchivedHtml("<p>nothing here</p>"), null);
  assert.equal(parseArchivedHtml('<script>{"price":5000}</script>'), null); // no compare-at info: skipped on purpose
});

test("archive helpers", () => {
  assert.equal(parseTs("20260312101500"), Date.UTC(2026, 2, 12, 10, 15, 0));
  const list = Array.from({ length: 100 }, (_, i) => i);
  const p = pickEvenly(list, 12);
  assert.equal(p.length, 12);
  assert.equal(p[0], 0);
  assert.equal(p.at(-1), 99);
  assert.equal(pickEvenly([1, 2], 12).length, 2);
});

test("views: audit rows, summary, overlay model, fakest-first sort", () => {
  let s = baseState();
  // a fake-looking product: flat for 30 days, claimed 50%
  const products = mkProducts(3);
  let r = applyCatalog(s, products, NOW - 30 * DAY, {});
  s = { ...s, ...r };
  const rows = buildAuditRows(s, NOW);
  assert.equal(rows.length, 3);
  assert.ok(rows.every((x) => x.audit.verdict === "FAKE"));
  const sum = summarizeRows(rows);
  assert.equal(sum.claimers, 3);
  assert.equal(sum.flaggedPct, 1);
  const o = overlayModel(s, "p0", NOW);
  assert.equal(o.verdict, "FAKE");
  assert.ok(o.spark.price.startsWith("M"));
  assert.equal(overlayModel(s, "nope", NOW), null);
  const sorted = [
    { audit: { verdict: "REAL", claimedPct: 0.5, realPct: 0.5 } },
    { audit: { verdict: "FAKE", claimedPct: 0.3, realPct: 0 } },
    { audit: { verdict: "MISLEADING", claimedPct: 0.6, realPct: 0.1 } },
  ].sort(fakestFirst);
  assert.deepEqual(sorted.map((x) => x.audit.verdict), ["FAKE", "MISLEADING", "REAL"]);
  assert.equal(pickPrimaryVariant({ variants: [{ avail: false, price: 1 }, { avail: true, price: 5 }, { avail: true, price: 3 }] }).price, 3);
});

test("thresholdsFromSettings converts percent to fractions", () => {
  const t = thresholdsFromSettings({ realMinPct: 15, ratioPct: 60, fakeMinClaim: 30, fakeStableDays: 10, minDays: 2 });
  assert.equal(t.realMinPct, 0.15);
  assert.equal(t.realToClaimRatio, 0.6);
  assert.equal(t.fakeMinClaim, 0.3);
  assert.equal(t.fakeStableDays, 10);
});
