# Audionic price collector (optional, free)

Audionic only shows today's prices, so the extension can only learn history from the day you install it.
This tiny collector runs on GitHub for free, records the prices every 6 hours, and publishes a `history.json`
that the extension can merge, so you get history for as long as the collector has been running.

## Set it up (5 minutes)

1. Create a **new public GitHub repository**, for example `audionic-history`.
2. Upload the files from this folder to the repository root, keeping the folder structure:
   - `collect.mjs`
   - `.github/workflows/collect.yml`
3. In the repository go to **Actions** and run **Collect Audionic prices** once with *Run workflow*.
   After about a minute a `history.json` file appears in the repository.
   (If the run fails with a permission error: Settings → Actions → General → Workflow permissions → *Read and write permissions*.)
4. Open `history.json` in the repository, click **Raw**, and copy the address. It looks like
   `https://raw.githubusercontent.com/YOUR-NAME/audionic-history/main/history.json`
5. In the extension: **Settings → Older prices → Shared history URL**, paste it, and press **Save & merge now**.

The workflow keeps running on its own every 6 hours. The extension re-merges the file automatically.

## Notes

- Only changes are stored (a new point is written only when a price, crossed-out price or stock status changes), so the file stays small.
- Prices are fetched from the store's public product list, the same data the website uses. No login, no scraping of private data.
- Anyone can use your `history.json` URL, so you can share it with friends: they paste it into their extension too.
- Scheduled GitHub workflows pause after 60 days without repository activity; this one commits whenever prices change, which keeps it alive.
- Run it on your own computer instead: `node collect.mjs` (Node 18+), then host the file anywhere that serves raw JSON on `raw.githubusercontent.com`.
