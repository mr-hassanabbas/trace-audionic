// Daily price collector for Audionic Price Check.
// Fetches https://audionic.co/products.json and appends a data point to history.json
// ONLY when a variant's price, crossed-out price or stock status changed.
//
// Run locally:  node collect.mjs            (needs Node 18+, no dependencies)
// Run on GitHub: see .github/workflows/collect.yml
//
// history.json format (read by the extension's "Shared history file" option):
// {
//   "version": 1,
//   "generated": "2026-11-10T06:00:00.000Z",
//   "variants": {
//     "48261384077468": {
//       "handle": "orchestra-pro-dolby-atmos",
//       "title": "Orchestra Pro ... ",
//       "pts": [ [timestampMs, price, compareAtOrNull, available 0|1], ... ]
//     }
//   }
// }
import { readFile, writeFile } from "node:fs/promises";

const ORIGIN = process.env.AUDIONIC_ORIGIN || "https://audionic.co";
const OUT = process.env.HISTORY_FILE || "history.json";
const NOW = Date.now();

const money = (v) => {
  if (v === null || v === undefined || v === "") return null;
  const n = parseFloat(String(v).replace(/[^\d.]/g, ""));
  return Number.isFinite(n) && n > 0 ? n : null;
};

async function fetchJson(url, tries = 4) {
  let err;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, { headers: { Accept: "application/json", "User-Agent": "audionic-price-collector (personal price history)" } });
      if (res.status === 429 || res.status >= 500) throw new Error("HTTP " + res.status);
      if (!res.ok) throw Object.assign(new Error("HTTP " + res.status), { fatal: true });
      return await res.json();
    } catch (e) {
      err = e;
      if (e.fatal) break;
      await new Promise((r) => setTimeout(r, 2000 * 2 ** i));
    }
  }
  throw err;
}

async function fetchAll() {
  const all = [];
  const seen = new Set();
  for (let page = 1; page <= 40; page++) {
    const data = await fetchJson(`${ORIGIN}/products.json?limit=250&page=${page}`);
    const list = (data && data.products) || [];
    if (!list.length) break;
    for (const p of list) if (!seen.has(p.id)) (seen.add(p.id), all.push(p));
    if (list.length < 250) break;
    await new Promise((r) => setTimeout(r, 600));
  }
  return all;
}

let db = { version: 1, generated: null, variants: {} };
try {
  const parsed = JSON.parse(await readFile(OUT, "utf8"));
  if (parsed && parsed.variants) db = parsed;
} catch {
  /* first run */
}

const products = await fetchAll();
if (!products.length) {
  console.error("No products returned; leaving history.json untouched.");
  process.exit(1);
}

let added = 0;
let created = 0;
for (const p of products) {
  for (const v of p.variants || []) {
    const price = money(v.price);
    if (price === null) continue;
    const cmp = money(v.compare_at_price);
    const avail = v.available ? 1 : 0;
    const key = String(v.id);
    let rec = db.variants[key];
    if (!rec) {
      rec = db.variants[key] = { handle: p.handle, title: p.title, pts: [] };
      created++;
    }
    rec.handle = p.handle;
    rec.title = p.title;
    const last = rec.pts[rec.pts.length - 1];
    if (!last || last[1] !== price || (last[2] ?? null) !== cmp || last[3] !== avail) {
      rec.pts.push([NOW, price, cmp, avail]);
      added++;
    }
  }
}

db.generated = new Date(NOW).toISOString();
await writeFile(OUT, JSON.stringify(db));
console.log(`Fetched ${products.length} products. New variants: ${created}. New data points: ${added}. File: ${OUT}`);
