// Runs on audionic.co pages. Content scripts can't use ES modules, so this file is self-contained.
// It never reads or changes anything about the user; it only (1) asks the extension for the verdict of
// the product being viewed and shows it in a small card, (2) marks product cards with a verdict dot,
// and (3) notes pressure tactics visible on the page (countdowns, "only N left", etc.).
(() => {
  if (window.__apcLoaded) return;
  window.__apcLoaded = true;

  const COLORS = { REAL: "#1E5BFF", MISLEADING: "#FF7A1A", FAKE: "#E8590C", NO_CLAIM: "#8AA0C4", COLLECTING: "#9DBBFF", NO_DATA: "#9DBBFF" };
  const LABELS = { REAL: "Real deal", MISLEADING: "Misleading", FAKE: "Fake-looking sale", NO_CLAIM: "No discount claimed", COLLECTING: "Collecting data", NO_DATA: "No data yet" };
  const COLLAPSE_KEY = "apc_overlay_collapsed";

  let settings = { overlay: true, productDots: true, urgency: true };
  let currentHandle = null;
  let hostEl = null;
  let alive = true;

  const alivePing = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  };

  function send(type, payload = {}) {
    return new Promise((resolve) => {
      if (!alivePing()) {
        alive = false;
        return resolve(null);
      }
      try {
        chrome.runtime.sendMessage({ type, ...payload }, (res) => {
          if (chrome.runtime.lastError || !res || !res.ok) return resolve(null);
          resolve(res.data);
        });
      } catch {
        alive = false;
        resolve(null);
      }
    });
  }

  const esc = (s) =>
    String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  const money = (n) => (n == null ? "—" : "Rs. " + Math.round(n).toLocaleString("en-US"));
  const pct = (x) => Math.round((x || 0) * 100) + "%";
  const handleFromPath = () => {
    const m = location.pathname.match(/\/products\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  };

  /* ================= overlay ================= */
  const CSS = `
    :host{all:initial}
    *{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
    .wrap{position:fixed;right:16px;bottom:16px;z-index:2147483000;color:#0A2A66}
    .card{width:268px;background:#fff;border:1px solid #D6E4FF;border-radius:14px;box-shadow:0 10px 30px rgba(10,42,102,.22);overflow:hidden}
    .hd{display:flex;align-items:center;gap:8px;padding:9px 10px;background:#0A2A66;color:#fff;font-size:12px;font-weight:600}
    .hd .logo{width:18px;height:18px;flex:none}
    .hd b{flex:1;letter-spacing:.2px}
    .hd button{all:unset;cursor:pointer;width:22px;height:22px;border-radius:6px;text-align:center;line-height:20px;font-size:16px;color:#fff}
    .hd button:hover{background:rgba(255,255,255,.15)}
    .body{padding:12px}
    .badge{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;color:#fff;background:var(--c)}
    .prices{display:flex;align-items:baseline;gap:8px;margin:10px 0 8px}
    .now{font-size:20px;font-weight:800;color:#0A2A66}
    s{color:#FF7A1A;font-size:13px;font-weight:600}
    .row{display:grid;grid-template-columns:48px 1fr 34px;gap:6px;align-items:center;font-size:11px;margin:4px 0;color:#5B6B8C}
    .track{height:7px;background:#EAF1FF;border-radius:6px;overflow:hidden}
    .track i{display:block;height:100%;border-radius:6px}
    .claimed i{background:#FF7A1A}
    .real i{background:#1E5BFF}
    .row em{font-style:normal;font-weight:700;color:#0A2A66;text-align:right}
    svg.spark{display:block;width:100%;height:46px;margin:8px 0 4px;background:#F6F9FF;border-radius:8px}
    .why{font-size:11.5px;line-height:1.4;margin:6px 0 2px;color:#0A2A66}
    .conf{font-size:10.5px;color:#5B6B8C;margin:2px 0 8px}
    .open{all:unset;cursor:pointer;display:block;text-align:center;font-size:12px;font-weight:700;color:#fff;background:#FF7A1A;border-radius:9px;padding:8px}
    .open:hover{background:#E8590C}
    .pill{all:unset;cursor:pointer;display:flex;align-items:center;gap:8px;padding:8px 12px 8px 8px;background:#fff;border:1px solid #D6E4FF;border-radius:999px;box-shadow:0 6px 20px rgba(10,42,102,.22);font-size:12px;font-weight:700;color:#0A2A66}
    .pill .dot{width:12px;height:12px;border-radius:50%;background:var(--c)}
    .hide{display:none!important}
  `;

  const LOGO = `<svg class="logo" viewBox="0 0 128 128" aria-hidden="true"><rect width="128" height="128" rx="28" fill="#1E5BFF"/><path d="M22 64 46 34H108V94H46Z" fill="#fff"/><circle cx="40" cy="64" r="7" fill="#1E5BFF"/><path d="M62 64 74 77 96 50" fill="none" stroke="#FF7A1A" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  function sparkSvg(s) {
    if (!s || !s.hasData) return "";
    const nd = s.noDataW > 6 ? `<rect x="0" y="0" width="${s.noDataW.toFixed(1)}" height="${s.h}" fill="#D6E4FF" opacity=".6"/>` : "";
    return `<svg class="spark" viewBox="0 0 ${s.w} ${s.h}" preserveAspectRatio="none" aria-label="Price over the last 90 days">${nd}
      <path d="${s.cmp}" fill="none" stroke="#FF7A1A" stroke-width="1.5" stroke-dasharray="4 3" vector-effect="non-scaling-stroke"/>
      <path d="${s.price}" fill="none" stroke="#1E5BFF" stroke-width="2.2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
  }

  async function getCollapsed() {
    try {
      const r = await chrome.storage.local.get(COLLAPSE_KEY);
      return !!r[COLLAPSE_KEY];
    } catch {
      return false;
    }
  }
  function setCollapsed(v) {
    try {
      chrome.storage.local.set({ [COLLAPSE_KEY]: !!v });
    } catch {
      /* ignore */
    }
  }

  function removeOverlay() {
    if (hostEl) {
      hostEl.remove();
      hostEl = null;
    }
  }

  async function renderOverlay() {
    if (!alive) return;
    const handle = handleFromPath();
    currentHandle = handle;
    if (!handle || !settings.overlay) {
      removeOverlay();
      send("badge", { verdict: null, text: "" });
      return;
    }
    const m = await send("overlay", { handle });
    if (!m) {
      // product not in the tracked catalogue yet (first sync may still be running)
      removeOverlay();
      send("badge", { verdict: null, text: "" });
      return;
    }
    send("badge", { verdict: m.verdict, text: m.short });
    const collapsed = await getCollapsed();
    if (!hostEl) {
      hostEl = document.createElement("div");
      hostEl.id = "apc-host";
      hostEl.attachShadow({ mode: "open" });
      document.documentElement.appendChild(hostEl);
    }
    const c = COLORS[m.verdict] || "#1E5BFF";
    const label = LABELS[m.verdict] || m.label;
    const claimed = m.claimedPct > 0;
    hostEl.shadowRoot.innerHTML = `<style>${CSS}</style>
      <div class="wrap" style="--c:${c}">
        <button class="pill ${collapsed ? "" : "hide"}" id="pill" title="Show price check"><span class="dot"></span>${esc(label)}</button>
        <div class="card ${collapsed ? "hide" : ""}" id="card">
          <div class="hd">${LOGO}<b>Audionic Price Check</b><button id="min" title="Collapse">–</button></div>
          <div class="body">
            <span class="badge">${esc(label)}</span>
            <div class="prices"><span class="now">${money(m.price)}</span>${m.cmp && m.cmp > m.price ? `<s>${money(m.cmp)}</s>` : ""}</div>
            ${
              claimed
                ? `<div class="row claimed"><span>Claimed</span><div class="track"><i style="width:${Math.min(100, Math.round(m.claimedPct * 100))}%"></i></div><em>${pct(m.claimedPct)}</em></div>
                   <div class="row real"><span>Real</span><div class="track"><i style="width:${Math.min(100, Math.round(m.realPct * 100))}%"></i></div><em>${pct(m.realPct)}</em></div>`
                : ""
            }
            ${sparkSvg(m.spark)}
            <p class="why">${esc(m.reason)}</p>
            <p class="conf">${esc(m.confidence)}</p>
            <button class="open" id="open">Open details</button>
          </div>
        </div>
      </div>`;
    const root = hostEl.shadowRoot;
    root.getElementById("min").onclick = () => {
      setCollapsed(true);
      root.getElementById("card").classList.add("hide");
      root.getElementById("pill").classList.remove("hide");
    };
    root.getElementById("pill").onclick = () => {
      setCollapsed(false);
      root.getElementById("pill").classList.add("hide");
      root.getElementById("card").classList.remove("hide");
    };
    root.getElementById("open").onclick = async () => {
      const r = await send("openPopup");
      if (!r || !r.opened) {
        const btn = root.getElementById("open");
        btn.textContent = "Click the extension icon in the toolbar";
        setTimeout(() => (btn.textContent = "Open details"), 2500);
      }
    };
  }

  /* ================= verdict dots on product cards ================= */
  let dotTimer = null;
  async function markCards() {
    if (!alive || !settings.productDots) return;
    const links = [...document.querySelectorAll('a[href*="/products/"]')].filter((a) => a.querySelector("img") && !a.dataset.apcDot).slice(0, 150);
    if (!links.length) return;
    const handleOf = (a) => {
      try {
        const m = new URL(a.href, location.origin).pathname.match(/\/products\/([^/?#]+)/);
        return m ? decodeURIComponent(m[1]) : null;
      } catch {
        return null;
      }
    };
    const handles = [...new Set(links.map(handleOf).filter(Boolean))];
    if (!handles.length) return;
    const map = await send("verdicts", { handles });
    if (!map) return;
    for (const a of links) {
      const v = map[handleOf(a)];
      a.dataset.apcDot = "1";
      if (!v || v.v === "NO_CLAIM") continue;
      if (getComputedStyle(a).position === "static") a.style.position = "relative";
      const dot = document.createElement("span");
      dot.className = "apc-dot";
      dot.title = `Audionic Price Check: ${LABELS[v.v] || v.label}` + (v.c > 0 ? ` (claimed ${pct(v.c)}, real ${pct(v.r)})` : "");
      dot.style.cssText = `position:absolute;top:6px;left:6px;width:14px;height:14px;border-radius:50%;background:${COLORS[v.v] || "#1E5BFF"};border:2px solid #fff;box-shadow:0 1px 4px rgba(10,42,102,.45);z-index:5;pointer-events:auto`;
      a.appendChild(dot);
    }
  }
  function scheduleDots() {
    clearTimeout(dotTimer);
    dotTimer = setTimeout(markCards, 800);
  }

  /* ================= urgency spotter ================= */
  const TEXT_TACTICS = [
    { name: "Discount badge (\"you saved X%\")", re: /\byou\s+sav(?:e|ed)\s+\d{1,3}\s*%|\bsave\s+\d{1,3}\s*%|\b\d{1,3}\s*%\s*off\b/i },
    { name: "Low-stock pressure (\"only N left\")", re: /\bonly\s+\d+\s+(?:items?\s+|units?\s+)?left\b|\b(?:few left|almost gone|selling fast|low stock|hurry)\b/i },
    { name: "Limited-time wording", re: /\b(?:limited[- ]time|last chance|ends?\s+(?:soon|today|tonight|in)|today only|flash sale|while stocks? last|don'?t miss)\b/i },
    { name: "Social proof (\"N people viewing/bought\")", re: /\b\d+\s+(?:people|customers|buyers|shoppers)\s+(?:are\s+)?(?:viewing|watching|looking|bought|purchased|have bought)\b/i },
  ];

  /** Parse "1d 02h 03m", "2h 5m 10s", "05 m 30 s", "01:02:03" into seconds, or null. */
  function parseTimer(s, allowColon) {
    s = String(s).replace(/\s+/g, " ").trim();
    let m;
    if ((m = /(\d{1,2})\s*d(?:ays?)?\s*[: ]\s*(\d{1,2})\s*h(?:ours?)?\s*[: ]\s*(\d{1,2})\s*m(?:in(?:utes?)?)?(?:\s*[: ]\s*(\d{1,2})\s*s(?:ec(?:onds?)?)?)?/i.exec(s)))
      return ((+m[1] * 24 + +m[2]) * 60 + +m[3]) * 60 + (+m[4] || 0);
    if ((m = /(\d{1,3})\s*h(?:ours?)?\s*[: ]\s*(\d{1,2})\s*m(?:in(?:utes?)?)?\s*[: ]\s*(\d{1,2})\s*s(?:ec(?:onds?)?)?/i.exec(s)))
      return (+m[1] * 60 + +m[2]) * 60 + +m[3];
    if ((m = /(\d{1,3})\s*m(?:in(?:utes?)?)?\s*[: ]\s*(\d{1,2})\s*s(?:ec(?:onds?)?)?\b/i.exec(s))) return +m[1] * 60 + +m[2];
    if (allowColon && (m = /\b(\d{1,3}):(\d{2}):(\d{2})\b/.exec(s))) return (+m[1] * 60 + +m[2]) * 60 + +m[3];
    return null;
  }

  function findCountdown() {
    const els = document.querySelectorAll('[class*="countdown" i],[id*="countdown" i],[class*="timer" i],[id*="timer" i],[data-countdown],[data-timer],[data-end-time]');
    for (const el of els) {
      const txt = (el.textContent || "").trim();
      if (!txt || txt.length > 80) continue;
      const r = parseTimer(txt, true);
      if (r !== null) return { remaining: r, text: txt };
    }
    // fallback: a short line of visible text that is only a timer, e.g. "00 m 00 s"
    const lines = (document.body.innerText || "").split("\n");
    for (const line of lines) {
      const t = line.trim();
      if (t.length < 4 || t.length > 40) continue;
      const r = parseTimer(t, false);
      if (r !== null) return { remaining: r, text: t };
    }
    return null;
  }

  let lastUrgencyKey = "";
  let lastUrgencySent = 0;
  async function scanUrgency() {
    if (!alive || !settings.urgency || !currentHandle || document.visibilityState !== "visible") return;
    const text = (document.body && document.body.innerText ? document.body.innerText : "").slice(0, 200000);
    const names = [];
    for (const t of TEXT_TACTICS) if (t.re.test(text)) names.push(t.name);
    if ((text.match(/sold\s*out/gi) || []).length >= 2) names.push("Sold-out variant labels");
    const cd = findCountdown();
    if (cd) names.unshift("Countdown timer");
    if (!names.length) return;
    const key = names.join("|") + "|" + (cd ? Math.floor(cd.remaining / 60) : "");
    const now = Date.now();
    if (key === lastUrgencyKey && now - lastUrgencySent < 120000) return;
    lastUrgencyKey = key;
    lastUrgencySent = now;
    await send("urgency", { handle: currentHandle, tactics: names, countdown: cd ? { remaining: cd.remaining, text: cd.text } : null });
  }

  /* ================= boot ================= */
  let lastHref = "";
  async function tick() {
    if (!alive) return;
    if (location.href !== lastHref) {
      lastHref = location.href;
      lastUrgencyKey = "";
      await renderOverlay();
      scheduleDots();
      setTimeout(scanUrgency, 2500);
    }
  }

  async function init() {
    const s = await send("contentSettings");
    if (s) settings = s;
    send("ensureFresh");
    await tick();
    const iv = setInterval(() => {
      if (!alive) return clearInterval(iv);
      tick();
    }, 1000);
    const iv2 = setInterval(() => {
      if (!alive) return clearInterval(iv2);
      scanUrgency();
    }, 20000);
    const iv3 = setInterval(() => {
      if (!alive) return clearInterval(iv3);
      if (document.visibilityState === "visible") renderOverlay();
    }, 5 * 60 * 1000);
    new MutationObserver(scheduleDots).observe(document.body, { childList: true, subtree: true });
    try {
      chrome.storage.onChanged.addListener(async (ch, area) => {
        if (area !== "local") return;
        if (ch.settings) {
          const ns = await send("contentSettings");
          if (ns) settings = ns;
          renderOverlay();
        }
      });
    } catch {
      /* ignore */
    }
  }

  init();
})();
